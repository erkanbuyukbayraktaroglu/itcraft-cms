<!doctype html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <title>@yield('title', 'Admin Panel') | {{ setting('site_name', 'Corporate CMS') }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">

    @if(setting('favicon'))
        <link rel="icon" type="image/png" href="{{ asset_upload(setting('favicon')) }}">
    @endif

    <style>
        :root {
            --admin-primary: #0f172a;
            --admin-secondary: #1e293b;
            --admin-accent: #c9a227;
            --admin-bg: #f5f7fb;
            --admin-text: #111827;
            --admin-muted: #6b7280;
            --admin-border: #e5e7eb;
            --admin-success-bg: #dcfce7;
            --admin-success-text: #166534;
            --admin-error-bg: #fee2e2;
            --admin-error-text: #991b1b;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: var(--admin-bg);
            color: var(--admin-text);
        }

        a { color: inherit; text-decoration: none; }

        .admin-shell {
            min-height: 100vh;
            display: grid;
            grid-template-columns: 260px 1fr;
        }

        .sidebar {
            background: var(--admin-primary);
            color: #ffffff;
            padding: 24px 18px;
        }

        .brand {
            font-size: 20px;
            font-weight: 800;
            line-height: 1.2;
            margin-bottom: 28px;
        }

        .brand span { color: var(--admin-accent); }

        .nav-title {
            color: rgba(255,255,255,.55);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .08em;
            margin: 22px 0 8px;
        }

        .nav-link {
            display: block;
            padding: 11px 12px;
            border-radius: 10px;
            color: rgba(255,255,255,.82);
            font-weight: 700;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,.1);
            color: #ffffff;
        }

        .main { min-width: 0; }

        .topbar {
            min-height: 72px;
            background: #ffffff;
            border-bottom: 1px solid var(--admin-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
        }

        .topbar-title {
            font-weight: 800;
            color: var(--admin-primary);
        }

        .user-info {
            color: var(--admin-muted);
            font-size: 14px;
        }

        .content { padding: 28px; }

        .page-title { margin-bottom: 24px; }

        .page-title h1 {
            margin: 0 0 6px;
            font-size: 28px;
            color: var(--admin-primary);
            letter-spacing: -0.03em;
        }

        .page-title p {
            margin: 0;
            color: var(--admin-muted);
        }

        .card {
            background: #ffffff;
            border: 1px solid var(--admin-border);
            border-radius: 18px;
            padding: 22px;
            box-shadow: 0 10px 26px rgba(15,23,42,.04);
        }

        .grid { display: grid; gap: 18px; }
        .grid-4 { grid-template-columns: repeat(4, 1fr); }

        .stat-card {
            background: #ffffff;
            border: 1px solid var(--admin-border);
            border-radius: 18px;
            padding: 22px;
            box-shadow: 0 10px 26px rgba(15,23,42,.04);
        }

        .stat-label {
            color: var(--admin-muted);
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .stat-number {
            color: var(--admin-primary);
            font-size: 34px;
            font-weight: 900;
            letter-spacing: -0.05em;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: 0;
            border-radius: 10px;
            padding: 10px 14px;
            background: var(--admin-primary);
            color: #ffffff;
            font-weight: 800;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            line-height: 1.2;
        }

        .btn-secondary { background: #e5e7eb; color: #111827; }
        .btn-danger { background: #dc2626; color: #ffffff; }

        .alert-success {
            background: var(--admin-success-bg);
            color: var(--admin-success-text);
            padding: 13px 15px;
            border-radius: 12px;
            font-weight: 700;
            margin-bottom: 18px;
        }

        .alert-error {
            background: var(--admin-error-bg);
            color: var(--admin-error-text);
            padding: 13px 15px;
            border-radius: 12px;
            font-weight: 700;
            margin-bottom: 18px;
        }

        .table-wrap { overflow-x: auto; }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 760px;
        }

        th, td {
            padding: 12px 14px;
            border-bottom: 1px solid var(--admin-border);
            text-align: left;
            vertical-align: middle;
        }

        th {
            background: #f9fafb;
            color: #374151;
            font-size: 13px;
        }

        .form-control {
            width: 100%;
            padding: 12px 13px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 15px;
            margin-bottom: 14px;
            background: #fff;
        }

        textarea.form-control {
            min-height: 140px;
            resize: vertical;
        }

        .editor-area {
            font-family: Consolas, Monaco, monospace;
            line-height: 1.55;
        }

        label {
            display: block;
            font-weight: 800;
            font-size: 14px;
            margin-bottom: 7px;
            color: #374151;
        }

        .form-grid { display: grid; gap: 16px; }
        .form-grid-2 { grid-template-columns: repeat(2, 1fr); }
        .form-grid-3 { grid-template-columns: repeat(3, 1fr); }

        .checkbox-row {
            display: flex;
            gap: 18px;
            flex-wrap: wrap;
            margin-top: 8px;
        }

        .checkbox-row label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin: 0;
        }

        .form-error {
            display: block;
            color: #991b1b;
            margin-top: -8px;
            margin-bottom: 12px;
            font-weight: 700;
        }

        .badge {
            display: inline-flex;
            padding: 5px 9px;
            border-radius: 999px;
            background: #e5e7eb;
            color: #374151;
            font-size: 12px;
            font-weight: 800;
        }

        .badge-success { background: #dcfce7; color: #166534; }
        .badge-danger { background: #fee2e2; color: #991b1b; }

        @media (max-width: 1000px) {
            .admin-shell { grid-template-columns: 1fr; }
            .sidebar { position: static; }
            .grid {
                grid-template-columns: 1fr !important;
            }
            .grid-4,
            .form-grid-2,
            .form-grid-3 { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 640px) {
            .content,
            .topbar {
                padding-left: 16px;
                padding-right: 16px;
            }

            .grid-4,
            .form-grid-2,
            .form-grid-3 { grid-template-columns: 1fr; }
        }
    </style>

    @stack('head')
<!-- admin-responsive-start -->
<style>
    @media (max-width: 991px) {
        body.admin-menu-open {
            overflow: hidden;
        }

        .admin-mobile-toggle {
            position: fixed;
            top: 14px;
            left: 14px;
            z-index: 3001;
            width: 44px;
            height: 44px;
            border: 0;
            border-radius: 12px;
            background: #111827;
            color: #ffffff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            cursor: pointer;
            box-shadow: 0 12px 30px rgba(15, 23, 42, .25);
        }

        .sidebar,
        .admin-sidebar {
            position: fixed !important;
            left: 0 !important;
            top: 0 !important;
            bottom: 0 !important;
            width: min(310px, 86vw) !important;
            z-index: 3000 !important;
            transform: translateX(-105%);
            transition: transform .22s ease;
            overflow-y: auto;
            box-shadow: 20px 0 60px rgba(15, 23, 42, .18);
        }

        body.admin-menu-open .sidebar,
        body.admin-menu-open .admin-sidebar {
            transform: translateX(0);
        }

        .main,
        .content,
        .admin-content,
        .main-content {
            margin-left: 0 !important;
            width: 100% !important;
            padding-left: 16px !important;
            padding-right: 16px !important;
        }

        .topbar,
        .admin-topbar {
            padding-left: 68px !important;
        }

        .dashboard-stats {
            grid-template-columns: 1fr !important;
        }

        .dashboard-grid {
            grid-template-columns: 1fr !important;
        }

        .form-grid,
        .form-grid-2 {
            grid-template-columns: 1fr !important;
        }

        .table-wrap {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        table {
            min-width: 760px;
        }
    }

    @media (min-width: 992px) {
        .admin-mobile-toggle {
            display: none !important;
        }
    }
</style>
<!-- admin-responsive-end -->
<!-- content-editor-style-start -->
<style>
    .ck-editor__editable {
        min-height: 320px;
        line-height: 1.7;
    }

    .ck-editor__editable_inline {
        border-bottom-left-radius: 14px !important;
        border-bottom-right-radius: 14px !important;
    }

    .ck.ck-toolbar {
        border-top-left-radius: 14px !important;
        border-top-right-radius: 14px !important;
    }

    .editor-help {
        display:block;
        color:#6b7280;
        margin-top:6px;
        font-size:13px;
        line-height:1.5;
    }

    @media (max-width: 768px) {
        .ck-editor__editable {
            min-height: 260px;
        }
    }
</style>
<!-- content-editor-style-end -->
<!-- media-picker-style-start -->
<style>
    .media-picker-button-group {
        display:flex;
        gap:8px;
        flex-wrap:wrap;
        margin-top:8px;
    }

    .media-picker-trigger,
    .media-preview-trigger {
        border:0;
        border-radius:10px;
        padding:9px 12px;
        cursor:pointer;
        font-weight:700;
        font-size:13px;
    }

    .media-picker-trigger {
        background:#111827;
        color:#fff;
    }

    .media-preview-trigger {
        background:#f3f4f6;
        color:#111827;
    }

    .media-picker-modal {
        position:fixed;
        inset:0;
        z-index:9999;
        display:none;
    }

    .media-picker-modal.is-open {
        display:block;
    }

    .media-picker-backdrop {
        position:absolute;
        inset:0;
        background:rgba(15, 23, 42, .65);
    }

    .media-picker-dialog {
        position:absolute;
        left:50%;
        top:50%;
        transform:translate(-50%, -50%);
        width:min(1100px, calc(100vw - 28px));
        height:min(760px, calc(100vh - 28px));
        background:#fff;
        border-radius:22px;
        overflow:hidden;
        box-shadow:0 30px 90px rgba(0,0,0,.35);
        display:flex;
        flex-direction:column;
    }

    .media-picker-top {
        height:58px;
        display:flex;
        align-items:center;
        justify-content:space-between;
        padding:0 18px;
        border-bottom:1px solid #e5e7eb;
        font-weight:800;
    }

    .media-picker-close {
        border:0;
        background:#fee2e2;
        color:#991b1b;
        border-radius:10px;
        padding:9px 12px;
        cursor:pointer;
        font-weight:800;
    }

    .media-picker-frame {
        width:100%;
        height:100%;
        border:0;
        flex:1;
    }

    @media (max-width: 768px) {
        .media-picker-dialog {
            width:100vw;
            height:100vh;
            border-radius:0;
        }
    }
</style>
<!-- media-picker-style-end -->
<!-- admin-ui-polish-start -->
<style>
    :root {
        --admin-bg: #f5f7fb;
        --admin-card: #ffffff;
        --admin-border: #e5e7eb;
        --admin-text: #111827;
        --admin-muted: #6b7280;
        --admin-soft: #f9fafb;
        --admin-primary: #111827;
        --admin-primary-hover: #000000;
        --admin-success-bg: #dcfce7;
        --admin-success-text: #166534;
        --admin-danger-bg: #fee2e2;
        --admin-danger-text: #991b1b;
        --admin-warning-bg: #fef3c7;
        --admin-warning-text: #92400e;
        --admin-info-bg: #dbeafe;
        --admin-info-text: #1e40af;
        --admin-radius: 16px;
        --admin-shadow: 0 12px 32px rgba(15, 23, 42, .07);
    }

    body {
        background: var(--admin-bg) !important;
        color: var(--admin-text);
        -webkit-font-smoothing: antialiased;
        text-rendering: optimizeLegibility;
    }

    a {
        color: inherit;
    }

    .page-title {
        margin-bottom: 22px;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
    }

    .page-title h1 {
        margin: 0;
        font-size: clamp(24px, 3vw, 34px);
        line-height: 1.15;
        letter-spacing: -0.035em;
        color: var(--admin-text);
    }

    .page-title p {
        margin: 8px 0 0;
        color: var(--admin-muted);
        line-height: 1.65;
        max-width: 760px;
    }

    .card {
        background: var(--admin-card) !important;
        border: 1px solid var(--admin-border) !important;
        border-radius: var(--admin-radius) !important;
        box-shadow: var(--admin-shadow) !important;
        padding: 22px !important;
        margin-bottom: 22px !important;
    }

    .card h2,
    .card h3 {
        margin-top: 0;
        color: var(--admin-text);
        letter-spacing: -0.025em;
    }

    .card h2 {
        font-size: 20px;
        margin-bottom: 14px;
    }

    .card h3 {
        font-size: 17px;
        margin-bottom: 12px;
    }

    .form-grid {
        display: grid;
        gap: 18px;
    }

    .form-grid-2 {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .form-grid-3 {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    label {
        display: block;
        font-weight: 800;
        color: #374151;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .form-control,
    input[type="text"],
    input[type="email"],
    input[type="url"],
    input[type="password"],
    input[type="number"],
    input[type="date"],
    input[type="datetime-local"],
    select,
    textarea {
        width: 100%;
        border: 1px solid #d1d5db !important;
        background: #ffffff !important;
        color: var(--admin-text) !important;
        border-radius: 13px !important;
        padding: 12px 14px !important;
        min-height: 44px;
        font-size: 14px;
        outline: none !important;
        transition: border-color .16s ease, box-shadow .16s ease, background .16s ease;
        box-sizing: border-box;
    }

    textarea {
        min-height: 130px;
        resize: vertical;
        line-height: 1.65;
    }

    .form-control:focus,
    input:focus,
    select:focus,
    textarea:focus {
        border-color: #111827 !important;
        box-shadow: 0 0 0 4px rgba(17, 24, 39, .09) !important;
    }

    input[type="color"] {
        width: 52px;
        height: 44px;
        padding: 4px !important;
        border-radius: 12px !important;
        border: 1px solid #d1d5db !important;
        background: #ffffff !important;
        cursor: pointer;
    }

    input[type="checkbox"] {
        width: 17px;
        height: 17px;
        accent-color: #111827;
        vertical-align: middle;
    }

    .checkbox-row label {
        display: inline-flex;
        align-items: center;
        gap: 9px;
        margin: 0;
        font-weight: 700;
    }

    .btn,
    button.btn,
    a.btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        min-height: 42px;
        padding: 10px 15px;
        border: 0;
        border-radius: 12px;
        background: var(--admin-primary);
        color: #ffffff !important;
        text-decoration: none !important;
        font-weight: 800;
        font-size: 14px;
        cursor: pointer;
        line-height: 1.2;
        transition: transform .16s ease, background .16s ease, box-shadow .16s ease;
        box-shadow: 0 8px 18px rgba(15, 23, 42, .12);
    }

    .btn:hover,
    button.btn:hover,
    a.btn:hover {
        background: var(--admin-primary-hover);
        transform: translateY(-1px);
        box-shadow: 0 12px 24px rgba(15, 23, 42, .16);
    }

    .btn-secondary,
    a.btn-secondary,
    button.btn-secondary {
        background: #f3f4f6 !important;
        color: #111827 !important;
        box-shadow: none !important;
        border: 1px solid #e5e7eb !important;
    }

    .btn-secondary:hover {
        background: #e5e7eb !important;
    }

    .btn-danger,
    a.btn-danger,
    button.btn-danger {
        background: #dc2626 !important;
        color: #ffffff !important;
    }

    .btn-danger:hover {
        background: #b91c1c !important;
    }

    .btn-sm {
        min-height: 34px !important;
        padding: 8px 11px !important;
        font-size: 13px !important;
        border-radius: 10px !important;
    }

    .alert,
    .alert-success,
    .alert-danger,
    .alert-warning,
    .alert-info {
        border-radius: 14px !important;
        padding: 14px 16px !important;
        border: 1px solid transparent !important;
        margin-bottom: 18px !important;
        line-height: 1.6;
        font-weight: 700;
    }

    .alert-success {
        background: var(--admin-success-bg) !important;
        color: var(--admin-success-text) !important;
        border-color: #86efac !important;
    }

    .alert-danger {
        background: var(--admin-danger-bg) !important;
        color: var(--admin-danger-text) !important;
        border-color: #fecaca !important;
    }

    .alert-warning {
        background: var(--admin-warning-bg) !important;
        color: var(--admin-warning-text) !important;
        border-color: #fde68a !important;
    }

    .alert-info {
        background: var(--admin-info-bg) !important;
        color: var(--admin-info-text) !important;
        border-color: #bfdbfe !important;
    }

    .table-wrap {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    table {
        width: 100%;
        border-collapse: separate !important;
        border-spacing: 0 !important;
        background: #ffffff;
        border: 1px solid var(--admin-border);
        border-radius: 16px;
        overflow: hidden;
    }

    table th,
    table td {
        padding: 13px 14px !important;
        border-bottom: 1px solid var(--admin-border) !important;
        text-align: left;
        vertical-align: middle;
        line-height: 1.5;
        font-size: 14px;
    }

    table th {
        background: #f9fafb !important;
        color: #374151 !important;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: .04em;
        font-weight: 900;
        white-space: nowrap;
    }

    table tr:last-child td {
        border-bottom: 0 !important;
    }

    table tbody tr {
        transition: background .14s ease;
    }

    table tbody tr:hover {
        background: #f9fafb;
    }

    table td img {
        border-radius: 12px;
        object-fit: cover;
        border: 1px solid #e5e7eb;
    }

    .badge,
    .status-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 26px;
        padding: 5px 10px;
        border-radius: 999px;
        font-weight: 900;
        font-size: 12px;
        line-height: 1;
        white-space: nowrap;
    }

    .badge-success,
    .status-active,
    .status-published {
        background: #dcfce7;
        color: #166534;
    }

    .badge-danger,
    .status-passive,
    .status-draft {
        background: #fee2e2;
        color: #991b1b;
    }

    .badge-warning {
        background: #fef3c7;
        color: #92400e;
    }

    .badge-info {
        background: #dbeafe;
        color: #1e40af;
    }

    .actions,
    .table-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }

    .actions form,
    .table-actions form {
        margin: 0;
    }

    .pagination {
        display: flex;
        align-items: center;
        gap: 6px;
        flex-wrap: wrap;
        margin-top: 18px;
    }

    .pagination a,
    .pagination span {
        min-width: 36px;
        height: 36px;
        border-radius: 10px;
        border: 1px solid var(--admin-border);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0 10px;
        text-decoration: none;
        color: #374151;
        background: #ffffff;
        font-weight: 800;
    }

    .pagination .active span,
    .pagination span[aria-current="page"] {
        background: #111827;
        color: #ffffff;
        border-color: #111827;
    }

    .dashboard-stats,
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 22px;
    }

    .stat-card,
    .dashboard-card {
        background: #ffffff;
        border: 1px solid var(--admin-border);
        border-radius: 18px;
        padding: 18px;
        box-shadow: var(--admin-shadow);
    }

    .stat-card strong,
    .dashboard-card strong {
        display: block;
        font-size: 28px;
        letter-spacing: -0.04em;
        color: #111827;
        margin-top: 6px;
    }

    .stat-card span,
    .dashboard-card span {
        color: #6b7280;
        font-weight: 800;
        font-size: 13px;
    }

    code {
        background: #f3f4f6;
        color: #111827;
        padding: 4px 7px;
        border-radius: 8px;
        font-size: 12px;
        word-break: break-word;
    }

    .admin-content,
    .main-content,
    .content {
        max-width: 100%;
    }

    .sidebar a,
    .admin-sidebar a {
        transition: background .16s ease, color .16s ease, transform .16s ease;
    }

    .sidebar a:hover,
    .admin-sidebar a:hover {
        transform: translateX(2px);
    }

    .ck-editor__editable {
        background: #ffffff !important;
    }

    .media-picker-button-group {
        margin-top: 8px;
    }

    @media (max-width: 1180px) {
        .dashboard-stats,
        .stats-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 991px) {
        .card {
            padding: 18px !important;
        }

        .form-grid-2,
        .form-grid-3,
        .settings-grid {
            grid-template-columns: 1fr !important;
        }

        table {
            min-width: 760px;
        }

        .page-title {
            display: block;
        }

        .page-title .btn,
        .page-title a.btn {
            margin-top: 12px;
        }
    }

    @media (max-width: 640px) {
        .dashboard-stats,
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .card {
            padding: 16px !important;
            border-radius: 14px !important;
        }

        .btn,
        button.btn,
        a.btn {
            width: 100%;
        }

        .actions,
        .table-actions {
            display: grid;
            grid-template-columns: 1fr;
            width: 100%;
        }

        .actions .btn,
        .table-actions .btn,
        .actions form,
        .table-actions form {
            width: 100%;
        }

        .page-title h1 {
            font-size: 25px;
        }

        input,
        select,
        textarea {
            font-size: 16px !important;
        }
    }
</style>
<!-- admin-ui-polish-end -->
<!-- auto-slug-v2-style-start -->
<style>
    .auto-slug-tools {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        align-items: center;
        margin-top: 8px;
    }

    .auto-slug-tools button {
        border: 0;
        border-radius: 10px;
        padding: 8px 11px;
        font-size: 13px;
        font-weight: 800;
        cursor: pointer;
        transition: .16s ease;
    }

    .auto-slug-refresh {
        background: #111827;
        color: #ffffff;
    }

    .auto-slug-lock {
        background: #f3f4f6;
        color: #111827;
        border: 1px solid #e5e7eb !important;
    }

    .auto-slug-status {
        display: inline-flex;
        align-items: center;
        min-height: 30px;
        padding: 0 10px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 800;
        background: #ecfdf5;
        color: #166534;
    }

    .auto-slug-status.is-locked {
        background: #fef3c7;
        color: #92400e;
    }

    .auto-slug-preview {
        display: block;
        margin-top: 8px;
        background: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        padding: 8px 10px;
        color: #4b5563;
        font-size: 12px;
        word-break: break-word;
    }

    .auto-slug-preview code {
        background: transparent;
        padding: 0;
        color: #111827;
        font-weight: 800;
    }

    .auto-slug-help {
        display:block;
        color:#6b7280;
        margin-top:6px;
        font-size:13px;
        line-height:1.5;
    }
</style>
<!-- auto-slug-v2-style-end -->
<!-- duplicate-content-style-start -->
<style>
    .duplicate-content-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 34px;
        padding: 8px 11px;
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        background: #f3f4f6;
        color: #111827;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        text-decoration: none;
        line-height: 1.2;
    }

    .duplicate-content-btn:hover {
        background: #e5e7eb;
    }
</style>
<!-- duplicate-content-style-end -->
<!-- preview-content-style-start -->
<style>
    .preview-content-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 34px;
        padding: 8px 11px;
        border: 1px solid #bfdbfe;
        border-radius: 10px;
        background: #dbeafe;
        color: #1e40af !important;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        text-decoration: none !important;
        line-height: 1.2;
    }

    .preview-content-btn:hover {
        background: #bfdbfe;
    }
</style>
<!-- preview-content-style-end -->
<!-- usage-guide-menu-style-start -->
<style>
    .usage-guide-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .usage-guide-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- usage-guide-menu-style-end -->
<!-- setup-checklist-style-start -->
<style>
    .setup-checklist-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .setup-checklist-menu-link:hover {
        background: rgba(255,255,255,.08);
    }

    .setup-checklist-install-banner {
        background: #fff7ed;
        border: 1px solid #fed7aa;
        color: #9a3412;
        padding: 14px 18px;
        border-radius: 14px;
        margin: 16px;
        line-height: 1.55;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 14px;
        box-shadow: 0 8px 20px rgba(15, 23, 42, .06);
    }

    .setup-checklist-install-banner strong {
        display: block;
        margin-bottom: 3px;
    }

    .setup-checklist-install-banner a {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: #111827;
        color: #fff !important;
        text-decoration: none !important;
        border-radius: 11px;
        padding: 10px 13px;
        font-weight: 800;
        white-space: nowrap;
    }

    @media (max-width: 768px) {
        .setup-checklist-install-banner {
            display: block;
        }

        .setup-checklist-install-banner a {
            margin-top: 10px;
            width: 100%;
        }
    }
</style>
<!-- setup-checklist-style-end -->
<!-- admin-users-menu-style-start -->
<style>
    .admin-users-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .admin-users-menu-link:hover {
        background: rgba(255,255,255,.08);
    }

    .table-actions button:disabled {
        opacity: .45;
        cursor: not-allowed;
    }
</style>
<!-- admin-users-menu-style-end -->
<!-- admin-sidebar-ui-upgrade-style-start -->
<style>
    :root {
        --sidebar-bg: #111827;
        --sidebar-bg-soft: rgba(255, 255, 255, .055);
        --sidebar-bg-hover: rgba(255, 255, 255, .095);
        --sidebar-text: #f9fafb;
        --sidebar-muted: #9ca3af;
        --sidebar-border: rgba(255, 255, 255, .08);
        --sidebar-accent: #f59e0b;
        --sidebar-danger: #ef4444;
    }

    .sidebar,
    .admin-sidebar,
    aside {
        scrollbar-width: thin;
        scrollbar-color: rgba(255,255,255,.25) transparent;
    }

    .sidebar::-webkit-scrollbar,
    .admin-sidebar::-webkit-scrollbar,
    aside::-webkit-scrollbar {
        width: 7px;
    }

    .sidebar::-webkit-scrollbar-thumb,
    .admin-sidebar::-webkit-scrollbar-thumb,
    aside::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,.18);
        border-radius: 999px;
    }

    .sidebar,
    .admin-sidebar {
        background: var(--sidebar-bg) !important;
        color: var(--sidebar-text) !important;
    }

    .admin-sidebar-brand {
        padding: 18px 18px 14px;
        border-bottom: 1px solid var(--sidebar-border);
        margin-bottom: 12px;
    }

    .admin-sidebar-brand-title {
        font-size: 18px;
        line-height: 1.15;
        font-weight: 900;
        letter-spacing: -.035em;
        color: #fff;
        margin: 0;
    }

    .admin-sidebar-brand-subtitle {
        display: block;
        color: var(--sidebar-muted);
        font-size: 12px;
        font-weight: 700;
        margin-top: 6px;
        letter-spacing: .04em;
        text-transform: uppercase;
    }

    .admin-sidebar-section {
        margin: 11px 10px;
    }

    .admin-sidebar-section-title {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        width: 100%;
        border: 0;
        background: transparent;
        color: var(--sidebar-muted);
        font-size: 11px;
        font-weight: 900;
        letter-spacing: .11em;
        text-transform: uppercase;
        padding: 10px 8px 7px;
        cursor: pointer;
        text-align: left;
    }

    .admin-sidebar-section-title::after {
        content: "⌄";
        font-size: 13px;
        opacity: .7;
        transform: rotate(0deg);
        transition: transform .16s ease;
    }

    .admin-sidebar-section.is-collapsed .admin-sidebar-section-title::after {
        transform: rotate(-90deg);
    }

    .admin-sidebar-section-links {
        display: grid;
        gap: 4px;
    }

    .admin-sidebar-section.is-collapsed .admin-sidebar-section-links {
        display: none;
    }

    .admin-sidebar-link {
        display: flex !important;
        align-items: center;
        gap: 10px;
        min-height: 40px;
        padding: 10px 11px !important;
        border-radius: 12px;
        color: #e5e7eb !important;
        text-decoration: none !important;
        font-size: 14px;
        font-weight: 750;
        line-height: 1.25;
        margin: 0 !important;
        background: transparent;
        transition: background .16s ease, color .16s ease, transform .16s ease;
    }

    .admin-sidebar-link:hover {
        background: var(--sidebar-bg-hover);
        color: #fff !important;
        transform: translateX(2px);
    }

    .admin-sidebar-link.is-active {
        background: rgba(245, 158, 11, .14);
        color: #fff !important;
        box-shadow: inset 3px 0 0 var(--sidebar-accent);
    }

    .admin-sidebar-link-icon {
        width: 22px;
        min-width: 22px;
        height: 22px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--sidebar-bg-soft);
        font-size: 13px;
    }

    .admin-sidebar-link-text {
        white-space: normal;
    }

    .admin-sidebar-divider {
        height: 1px;
        background: var(--sidebar-border);
        margin: 12px 18px;
    }

    .admin-sidebar-logout {
        margin: 14px 10px 16px !important;
        background: var(--sidebar-danger) !important;
        color: #fff !important;
        border-radius: 13px !important;
        min-height: 44px !important;
        display: flex !important;
        justify-content: center !important;
        font-weight: 900 !important;
        box-shadow: 0 10px 22px rgba(239, 68, 68, .22);
    }

    .admin-sidebar-logout:hover {
        background: #dc2626 !important;
        transform: translateY(-1px);
    }

    .admin-sidebar-compact-toggle {
        position: sticky;
        bottom: 10px;
        z-index: 3;
        margin: 12px 10px 6px;
        border: 1px solid var(--sidebar-border);
        background: rgba(255,255,255,.06);
        color: #fff;
        border-radius: 12px;
        padding: 10px 12px;
        font-weight: 800;
        cursor: pointer;
        width: calc(100% - 20px);
    }

    body.admin-sidebar-compact .sidebar,
    body.admin-sidebar-compact .admin-sidebar {
        width: 84px !important;
        min-width: 84px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-brand-title,
    body.admin-sidebar-compact .admin-sidebar-brand-subtitle,
    body.admin-sidebar-compact .admin-sidebar-section-title span,
    body.admin-sidebar-compact .admin-sidebar-section-title::after,
    body.admin-sidebar-compact .admin-sidebar-link-text,
    body.admin-sidebar-compact .admin-sidebar-compact-toggle span {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-brand {
        padding: 16px 10px;
        text-align: center;
    }

    body.admin-sidebar-compact .admin-sidebar-brand::after {
        content: "YP";
        display: inline-flex;
        width: 42px;
        height: 42px;
        align-items: center;
        justify-content: center;
        border-radius: 14px;
        background: rgba(245, 158, 11, .16);
        color: #fff;
        font-weight: 900;
    }

    body.admin-sidebar-compact .admin-sidebar-section {
        margin-left: 8px;
        margin-right: 8px;
    }

    body.admin-sidebar-compact .admin-sidebar-section-title {
        justify-content: center;
        padding: 6px;
    }

    body.admin-sidebar-compact .admin-sidebar-link {
        justify-content: center;
        padding: 11px 8px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-link-icon {
        width: 32px;
        height: 32px;
        min-width: 32px;
        font-size: 15px;
    }

    body.admin-sidebar-compact .admin-sidebar-logout {
        padding: 10px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout .admin-sidebar-link-text {
        display: none !important;
    }

    @media (max-width: 768px) {
        .admin-sidebar-section {
            margin: 8px 10px;
        }

        .admin-sidebar-link {
            min-height: 42px;
        }

        .admin-sidebar-compact-toggle {
            display: none;
        }
    }
</style>
<!-- admin-sidebar-ui-upgrade-style-end -->
<!-- admin-sidebar-experience-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Sidebar Experience Upgrade
    |--------------------------------------------------------------------------
    */

    .admin-sidebar-search-wrap {
        padding: 0 14px 12px;
        border-bottom: 1px solid rgba(255,255,255,.07);
        margin-bottom: 8px;
    }

    .admin-sidebar-search {
        width: 100%;
        min-height: 40px;
        border: 1px solid rgba(255,255,255,.12) !important;
        background: rgba(255,255,255,.06) !important;
        color: #f9fafb !important;
        border-radius: 13px !important;
        padding: 10px 12px 10px 36px !important;
        outline: none !important;
        font-size: 13px !important;
        font-weight: 700;
        box-sizing: border-box;
        background-image:
            linear-gradient(transparent, transparent),
            url("data:image/svg+xml,%3Csvg width='18' height='18' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M21 21L16.65 16.65M19 11C19 15.4183 15.4183 19 11 19C6.58172 19 3 15.4183 3 11C3 6.58172 6.58172 3 11 3C15.4183 3 19 6.58172 19 11Z' stroke='%239ca3af' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: 11px center;
    }

    .admin-sidebar-search::placeholder {
        color: #9ca3af;
    }

    .admin-sidebar-search:focus {
        border-color: rgba(245, 158, 11, .55) !important;
        box-shadow: 0 0 0 4px rgba(245, 158, 11, .13) !important;
        background-color: rgba(255,255,255,.09) !important;
    }

    .admin-sidebar-search-empty {
        display: none;
        color: #9ca3af;
        font-size: 13px;
        font-weight: 700;
        padding: 14px;
        margin: 0 10px;
        border-radius: 12px;
        background: rgba(255,255,255,.04);
        line-height: 1.5;
    }

    .admin-sidebar-search-empty.is-visible {
        display: block;
    }

    .admin-sidebar-link.is-active {
        background: linear-gradient(90deg, rgba(245, 158, 11, .22), rgba(245, 158, 11, .08)) !important;
        color: #ffffff !important;
        box-shadow:
            inset 4px 0 0 #f59e0b,
            0 10px 22px rgba(0, 0, 0, .12);
        transform: translateX(2px);
    }

    .admin-sidebar-link.is-active .admin-sidebar-link-icon {
        background: rgba(245, 158, 11, .24);
        color: #ffffff;
    }

    .admin-sidebar-link.is-hidden-by-search,
    .admin-sidebar-section.is-hidden-by-search {
        display: none !important;
    }

    .admin-sidebar-bottom {
        margin-top: auto;
        padding: 10px 0 4px;
        border-top: 1px solid rgba(255,255,255,.08);
    }

    .sidebar,
    .admin-sidebar,
    aside {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .admin-sidebar-logout {
        margin-top: 10px !important;
        margin-bottom: 12px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-search-wrap {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-search-empty {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-bottom {
        border-top: 0;
    }

    body.admin-sidebar-compact .admin-sidebar-section.is-default-collapsed {
        display: block;
    }

    .admin-sidebar-section.is-default-collapsed .admin-sidebar-section-title {
        opacity: .92;
    }

    .admin-sidebar-section-title span::before {
        margin-right: 0;
    }

    @media (max-width: 768px) {
        .admin-sidebar-search-wrap {
            padding: 0 12px 10px;
        }

        .admin-sidebar-search {
            min-height: 42px;
            font-size: 14px !important;
        }

        .admin-sidebar-bottom {
            margin-top: 8px;
        }
    }
</style>
<!-- admin-sidebar-experience-style-end -->
<!-- sidebar-logout-button-style-start -->
<style>
    .admin-sidebar-bottom {
        margin-top: auto !important;
        padding: 12px 10px 16px !important;
        border-top: 1px solid rgba(255,255,255,.08);
    }

    .admin-sidebar-logout-fixed {
        display: flex !important;
        align-items: center;
        justify-content: center;
        gap: 9px;
        width: 100%;
        min-height: 46px;
        padding: 12px 14px !important;
        border-radius: 14px !important;
        background: #ef4444 !important;
        color: #ffffff !important;
        text-decoration: none !important;
        font-weight: 900 !important;
        font-size: 14px;
        box-shadow: 0 10px 22px rgba(239, 68, 68, .24);
        transition: background .16s ease, transform .16s ease, box-shadow .16s ease;
    }

    .admin-sidebar-logout-fixed:hover {
        background: #dc2626 !important;
        color: #ffffff !important;
        transform: translateY(-1px);
        box-shadow: 0 14px 26px rgba(239, 68, 68, .30);
    }

    .admin-sidebar-logout-fixed-icon {
        width: 22px;
        height: 22px;
        min-width: 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(255,255,255,.16);
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed-text {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed {
        padding: 12px 8px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-bottom {
        padding-left: 8px !important;
        padding-right: 8px !important;
    }
</style>
<!-- sidebar-logout-button-style-end -->
<!-- logout-post-button-style-start -->
<style>
    .admin-sidebar-bottom {
        margin-top: auto !important;
        padding: 12px 10px 16px !important;
        border-top: 1px solid rgba(255,255,255,.08);
    }

    .admin-sidebar-logout-form {
        width: 100%;
        margin: 0 !important;
        padding: 0 !important;
    }

    .admin-sidebar-logout-post-button {
        display: flex !important;
        align-items: center;
        justify-content: center;
        gap: 9px;
        width: 100%;
        min-height: 46px;
        padding: 12px 14px !important;
        border: 0 !important;
        border-radius: 14px !important;
        background: #ef4444 !important;
        color: #ffffff !important;
        text-decoration: none !important;
        font-weight: 900 !important;
        font-size: 14px;
        cursor: pointer;
        box-shadow: 0 10px 22px rgba(239, 68, 68, .24);
        transition: background .16s ease, transform .16s ease, box-shadow .16s ease;
    }

    .admin-sidebar-logout-post-button:hover {
        background: #dc2626 !important;
        color: #ffffff !important;
        transform: translateY(-1px);
        box-shadow: 0 14px 26px rgba(239, 68, 68, .30);
    }

    .admin-sidebar-logout-fixed-icon {
        width: 22px;
        height: 22px;
        min-width: 22px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        background: rgba(255,255,255,.16);
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed-text {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-post-button {
        padding: 12px 8px !important;
    }

    body.admin-sidebar-compact .admin-sidebar-bottom {
        padding-left: 8px !important;
        padding-right: 8px !important;
    }
</style>
<!-- logout-post-button-style-end -->
<!-- dashboard-cards-polish-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Dashboard Cards Polish
    |--------------------------------------------------------------------------
    */

    body[class*="admin"] .dashboard-stats,
    body[class*="admin"] .stats-grid,
    .dashboard-stats,
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 18px;
        margin-bottom: 24px;
    }

    .dashboard-stat-polished,
    .stat-card.dashboard-stat-polished,
    .dashboard-card.dashboard-stat-polished {
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(229, 231, 235, .9) !important;
        border-radius: 22px !important;
        padding: 20px !important;
        min-height: 132px;
        background: #ffffff !important;
        box-shadow: 0 16px 36px rgba(15, 23, 42, .08) !important;
        transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease;
    }

    .dashboard-stat-polished:hover {
        transform: translateY(-3px);
        box-shadow: 0 22px 46px rgba(15, 23, 42, .13) !important;
        border-color: rgba(209, 213, 219, 1) !important;
    }

    .dashboard-stat-polished::before {
        content: "";
        position: absolute;
        inset: 0;
        background:
            radial-gradient(circle at top right, var(--stat-soft, rgba(59, 130, 246, .14)), transparent 42%),
            linear-gradient(135deg, var(--stat-tint, rgba(59, 130, 246, .08)), transparent 55%);
        pointer-events: none;
    }

    .dashboard-stat-polished::after {
        content: "";
        position: absolute;
        right: -34px;
        bottom: -34px;
        width: 110px;
        height: 110px;
        border-radius: 999px;
        background: var(--stat-soft, rgba(59, 130, 246, .12));
        pointer-events: none;
    }

    .dashboard-stat-inner {
        position: relative;
        z-index: 2;
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 14px;
    }

    .dashboard-stat-main {
        min-width: 0;
    }

    .dashboard-stat-label {
        display: block;
        color: #64748b;
        font-size: 13px;
        font-weight: 900;
        letter-spacing: .035em;
        text-transform: uppercase;
        margin-bottom: 10px;
    }

    .dashboard-stat-value {
        display: block;
        color: #0f172a;
        font-size: clamp(30px, 4vw, 42px);
        line-height: 1;
        font-weight: 950;
        letter-spacing: -.06em;
        margin-bottom: 8px;
    }

    .dashboard-stat-hint {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: #64748b;
        font-size: 12px;
        font-weight: 750;
        background: rgba(255, 255, 255, .72);
        border: 1px solid rgba(226, 232, 240, .8);
        border-radius: 999px;
        padding: 5px 9px;
        backdrop-filter: blur(8px);
    }

    .dashboard-stat-icon {
        width: 52px;
        height: 52px;
        min-width: 52px;
        border-radius: 18px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        font-size: 24px;
        background: linear-gradient(135deg, var(--stat-color, #3b82f6), var(--stat-color-dark, #1d4ed8));
        box-shadow: 0 14px 26px var(--stat-shadow, rgba(59, 130, 246, .28));
    }

    .dashboard-stat-polished.stat-blue {
        --stat-color: #3b82f6;
        --stat-color-dark: #1d4ed8;
        --stat-soft: rgba(59, 130, 246, .16);
        --stat-tint: rgba(59, 130, 246, .08);
        --stat-shadow: rgba(59, 130, 246, .28);
    }

    .dashboard-stat-polished.stat-green {
        --stat-color: #10b981;
        --stat-color-dark: #047857;
        --stat-soft: rgba(16, 185, 129, .16);
        --stat-tint: rgba(16, 185, 129, .08);
        --stat-shadow: rgba(16, 185, 129, .28);
    }

    .dashboard-stat-polished.stat-purple {
        --stat-color: #8b5cf6;
        --stat-color-dark: #6d28d9;
        --stat-soft: rgba(139, 92, 246, .16);
        --stat-tint: rgba(139, 92, 246, .08);
        --stat-shadow: rgba(139, 92, 246, .28);
    }

    .dashboard-stat-polished.stat-orange {
        --stat-color: #f59e0b;
        --stat-color-dark: #d97706;
        --stat-soft: rgba(245, 158, 11, .18);
        --stat-tint: rgba(245, 158, 11, .09);
        --stat-shadow: rgba(245, 158, 11, .30);
    }

    .dashboard-stat-polished.stat-red {
        --stat-color: #ef4444;
        --stat-color-dark: #b91c1c;
        --stat-soft: rgba(239, 68, 68, .16);
        --stat-tint: rgba(239, 68, 68, .08);
        --stat-shadow: rgba(239, 68, 68, .28);
    }

    .dashboard-stat-polished.stat-cyan {
        --stat-color: #06b6d4;
        --stat-color-dark: #0e7490;
        --stat-soft: rgba(6, 182, 212, .16);
        --stat-tint: rgba(6, 182, 212, .08);
        --stat-shadow: rgba(6, 182, 212, .28);
    }

    .dashboard-stat-polished.stat-slate {
        --stat-color: #334155;
        --stat-color-dark: #0f172a;
        --stat-soft: rgba(51, 65, 85, .14);
        --stat-tint: rgba(51, 65, 85, .07);
        --stat-shadow: rgba(51, 65, 85, .24);
    }

    .dashboard-stat-polished.stat-pink {
        --stat-color: #ec4899;
        --stat-color-dark: #be185d;
        --stat-soft: rgba(236, 72, 153, .15);
        --stat-tint: rgba(236, 72, 153, .075);
        --stat-shadow: rgba(236, 72, 153, .26);
    }

    .dashboard-quick-polish {
        border-radius: 20px !important;
        border: 1px solid #e5e7eb !important;
        box-shadow: 0 14px 32px rgba(15, 23, 42, .07) !important;
    }

    @media (max-width: 1180px) {
        body[class*="admin"] .dashboard-stats,
        body[class*="admin"] .stats-grid,
        .dashboard-stats,
        .stats-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }

    @media (max-width: 640px) {
        body[class*="admin"] .dashboard-stats,
        body[class*="admin"] .stats-grid,
        .dashboard-stats,
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .dashboard-stat-polished {
            min-height: 118px;
            padding: 18px !important;
        }

        .dashboard-stat-icon {
            width: 48px;
            height: 48px;
            min-width: 48px;
            border-radius: 16px;
            font-size: 22px;
        }
    }
</style>
<!-- dashboard-cards-polish-style-end -->
<!-- dashboard-card-title-fix-style-start -->
<style>
    .dashboard-stat-polished {
        min-height: 138px !important;
    }

    .dashboard-stat-inner {
        height: 100%;
    }

    .dashboard-stat-label {
        font-size: 15px !important;
        line-height: 1.25 !important;
        letter-spacing: -0.01em !important;
        text-transform: none !important;
        color: #334155 !important;
        font-weight: 900 !important;
        margin-bottom: 8px !important;
        max-width: 230px;
    }

    .dashboard-stat-value {
        font-size: 28px !important;
        line-height: 1 !important;
        letter-spacing: -0.04em !important;
        margin-bottom: 10px !important;
    }

    .dashboard-stat-hint {
        font-size: 12px !important;
        font-weight: 800 !important;
        color: #64748b !important;
        max-width: 230px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .dashboard-stat-icon {
        width: 54px !important;
        height: 54px !important;
        min-width: 54px !important;
        font-size: 23px !important;
    }

    @media (max-width: 640px) {
        .dashboard-stat-label,
        .dashboard-stat-hint {
            max-width: 100%;
        }

        .dashboard-stat-hint {
            white-space: normal;
        }
    }
</style>
<!-- dashboard-card-title-fix-style-end -->
<!-- mobile-sidebar-logout-fix-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Mobile Sidebar Logout Visibility Fix
    |--------------------------------------------------------------------------
    */

    .sidebar,
    .admin-sidebar,
    aside {
        max-height: 100vh;
        overflow-y: auto;
        overflow-x: hidden;
    }

    .admin-sidebar-bottom {
        flex-shrink: 0;
    }

    @media (max-width: 768px) {
        .sidebar,
        .admin-sidebar,
        aside {
            height: 100dvh !important;
            max-height: 100dvh !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            display: flex !important;
            flex-direction: column !important;
            padding-bottom: env(safe-area-inset-bottom, 0px);
            -webkit-overflow-scrolling: touch;
        }

        .admin-sidebar-brand {
            flex-shrink: 0;
        }

        .admin-sidebar-search-wrap {
            flex-shrink: 0;
        }

        .admin-sidebar-section {
            flex-shrink: 0;
        }

        .admin-sidebar-bottom {
            position: sticky !important;
            bottom: 0 !important;
            z-index: 20 !important;
            margin-top: 12px !important;
            padding: 12px 10px calc(14px + env(safe-area-inset-bottom, 0px)) !important;
            background: linear-gradient(
                180deg,
                rgba(17, 24, 39, .84),
                rgba(17, 24, 39, 1) 34%
            ) !important;
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255,255,255,.10) !important;
        }

        .admin-sidebar-logout-form {
            display: block !important;
            width: 100% !important;
        }

        .admin-sidebar-logout-post-button,
        .admin-sidebar-logout-fixed {
            width: 100% !important;
            min-height: 46px !important;
            display: flex !important;
            visibility: visible !important;
            opacity: 1 !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom {
            padding-left: 8px !important;
            padding-right: 8px !important;
        }

        body.admin-sidebar-compact .admin-sidebar-logout-post-button,
        body.admin-sidebar-compact .admin-sidebar-logout-fixed {
            min-height: 44px !important;
        }
    }

    @media (max-width: 768px) and (orientation: portrait) {
        .sidebar,
        .admin-sidebar,
        aside {
            height: 100dvh !important;
            max-height: 100dvh !important;
        }

        .admin-sidebar-bottom {
            bottom: 0 !important;
        }
    }

    @media (max-width: 768px) and (max-height: 720px) {
        .admin-sidebar-brand {
            padding-top: 12px !important;
            padding-bottom: 10px !important;
        }

        .admin-sidebar-section {
            margin-top: 6px !important;
            margin-bottom: 6px !important;
        }

        .admin-sidebar-link {
            min-height: 38px !important;
            padding-top: 8px !important;
            padding-bottom: 8px !important;
        }

        .admin-sidebar-section-title {
            padding-top: 7px !important;
            padding-bottom: 5px !important;
        }

        .admin-sidebar-search {
            min-height: 38px !important;
        }
    }
</style>
<!-- mobile-sidebar-logout-fix-style-end -->
<!-- clean-admin-topbar-user-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Clean Admin Topbar User Info
    |--------------------------------------------------------------------------
    */

    .topbar .user-info,
    .topbar .user-details,
    .topbar .user-name,
    .topbar .user-email,
    .topbar .admin-user-info,
    .topbar .admin-user-details,
    .topbar .profile-info,
    .topbar .profile-details,
    .topbar [class*="user-email"],
    .topbar [class*="user-name"],
    .topbar [class*="profile-email"],
    .topbar [class*="profile-name"],
    .admin-topbar .user-info,
    .admin-topbar .user-details,
    .admin-topbar .user-name,
    .admin-topbar .user-email,
    .admin-topbar .admin-user-info,
    .admin-topbar .admin-user-details,
    .admin-topbar .profile-info,
    .admin-topbar .profile-details,
    .admin-topbar [class*="user-email"],
    .admin-topbar [class*="user-name"],
    .admin-topbar [class*="profile-email"],
    .admin-topbar [class*="profile-name"],
    header .user-info,
    header .user-details,
    header .user-name,
    header .user-email,
    header .admin-user-info,
    header .admin-user-details,
    header .profile-info,
    header .profile-details {
        display: none !important;
    }

    .topbar,
    .admin-topbar,
    header {
        gap: 12px;
    }

    .topbar-right,
    .admin-topbar-right,
    .header-right {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-left: auto;
    }

    .topbar a[href*="logout"],
    .admin-topbar a[href*="logout"],
    header a[href*="logout"],
    .topbar form[action*="logout"],
    .admin-topbar form[action*="logout"],
    header form[action*="logout"] {
        display: none !important;
    }

    .admin-topbar-cleaned-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 36px;
        height: 36px;
        border-radius: 999px;
        background: #f3f4f6;
        color: #111827;
        font-weight: 900;
        font-size: 14px;
        border: 1px solid #e5e7eb;
    }

    @media (max-width: 768px) {
        .admin-topbar-cleaned-badge {
            display: none;
        }
    }
</style>
<!-- clean-admin-topbar-user-style-end -->
<!-- login-attempts-menu-style-start -->
<style>
    .login-attempts-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .login-attempts-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- login-attempts-menu-style-end -->
<!-- compact-bottom-buttons-fix-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Compact Sidebar Bottom Buttons Fix
    |--------------------------------------------------------------------------
    | Sadece daraltılmış sidebar modunda alttaki Daralt ve Çıkış butonlarını
    | daha düzgün gösterir.
    |--------------------------------------------------------------------------
    */

    body.admin-sidebar-compact .admin-sidebar-compact-toggle {
        width: 44px !important;
        height: 44px !important;
        min-width: 44px !important;
        min-height: 44px !important;
        margin: 12px auto 10px !important;
        padding: 0 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        border-radius: 14px !important;
        background: rgba(255, 255, 255, .075) !important;
        border: 1px solid rgba(255, 255, 255, .12) !important;
        color: #f9fafb !important;
        box-shadow: none !important;
        font-size: 0 !important;
        line-height: 1 !important;
    }

    body.admin-sidebar-compact .admin-sidebar-compact-toggle::before {
        content: "☰";
        font-size: 20px;
        line-height: 1;
        font-weight: 900;
        color: #f9fafb;
    }

    body.admin-sidebar-compact .admin-sidebar-compact-toggle:hover {
        background: rgba(255, 255, 255, .13) !important;
        border-color: rgba(255, 255, 255, .18) !important;
        transform: translateY(-1px);
    }

    body.admin-sidebar-compact .admin-sidebar-compact-toggle span {
        display: none !important;
    }

    body.admin-sidebar-compact .admin-sidebar-bottom {
        padding: 10px 8px 14px !important;
        margin-top: auto !important;
        border-top: 1px solid rgba(255, 255, 255, .08) !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-form {
        width: 100% !important;
        display: flex !important;
        justify-content: center !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-post-button,
    body.admin-sidebar-compact .admin-sidebar-logout-fixed {
        width: 48px !important;
        height: 48px !important;
        min-width: 48px !important;
        min-height: 48px !important;
        max-width: 48px !important;
        padding: 0 !important;
        margin: 0 auto !important;
        border-radius: 16px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: linear-gradient(135deg, #ef4444, #dc2626) !important;
        color: #ffffff !important;
        border: 1px solid rgba(255, 255, 255, .12) !important;
        box-shadow: 0 12px 26px rgba(239, 68, 68, .34) !important;
        font-size: 0 !important;
        overflow: hidden !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-post-button:hover,
    body.admin-sidebar-compact .admin-sidebar-logout-fixed:hover {
        background: linear-gradient(135deg, #f43f5e, #dc2626) !important;
        transform: translateY(-1px);
        box-shadow: 0 16px 30px rgba(239, 68, 68, .42) !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed-icon {
        width: 34px !important;
        height: 34px !important;
        min-width: 34px !important;
        border-radius: 12px !important;
        background: rgba(255, 255, 255, .17) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 0 !important;
        line-height: 1 !important;
        color: #ffffff !important;
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed-icon::before {
        content: "⎋";
        font-size: 22px;
        line-height: 1;
        font-weight: 900;
        color: #ffffff;
        transform: translateY(-1px);
    }

    body.admin-sidebar-compact .admin-sidebar-logout-fixed-text {
        display: none !important;
    }

    /*
    |--------------------------------------------------------------------------
    | Geniş sidebar modunda butonlar mevcut görünümü korusun
    |--------------------------------------------------------------------------
    */

    body:not(.admin-sidebar-compact) .admin-sidebar-compact-toggle {
        font-size: 14px !important;
    }

    body:not(.admin-sidebar-compact) .admin-sidebar-logout-fixed-icon::before {
        content: none !important;
    }
</style>
<!-- compact-bottom-buttons-fix-style-end -->
<!-- theme-settings-menu-style-start -->
<style>
    .theme-settings-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .theme-settings-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- theme-settings-menu-style-end -->
<!-- sidebar-layout-stability-style-start -->
<style>
    /*
    |--------------------------------------------------------------------------
    | Sidebar Layout Stability
    |--------------------------------------------------------------------------
    | Menü alanı scroll olur, alt aksiyonlar sabit kalır.
    |--------------------------------------------------------------------------
    */

    .sidebar,
    .admin-sidebar,
    aside {
        background: #111827 !important;
    }

    @media (min-width: 769px) {
        .sidebar,
        .admin-sidebar,
        aside {
            position: sticky !important;
            top: 0 !important;
            align-self: flex-start !important;
            height: 100vh !important;
            height: 100dvh !important;
            max-height: 100vh !important;
            max-height: 100dvh !important;
            min-height: 100vh !important;
            min-height: 100dvh !important;
            overflow: hidden !important;
            display: flex !important;
            flex-direction: column !important;
            background: #111827 !important;
        }

        .admin-sidebar-scroll-area {
            flex: 1 1 auto !important;
            min-height: 0 !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            padding-bottom: 10px !important;
            scrollbar-width: thin;
            scrollbar-color: rgba(255,255,255,.26) transparent;
        }

        .admin-sidebar-scroll-area::-webkit-scrollbar {
            width: 7px;
        }

        .admin-sidebar-scroll-area::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,.22);
            border-radius: 999px;
        }

        .admin-sidebar-scroll-area::-webkit-scrollbar-track {
            background: transparent;
        }

        .admin-sidebar-bottom {
            flex: 0 0 auto !important;
            margin-top: 0 !important;
            padding: 12px 10px 14px !important;
            border-top: 1px solid rgba(255,255,255,.10) !important;
            background: linear-gradient(180deg, rgba(17,24,39,.94), #111827) !important;
            z-index: 5 !important;
        }

        .admin-sidebar-bottom .admin-sidebar-compact-toggle {
            width: 100% !important;
            margin: 0 0 10px !important;
        }

        .admin-sidebar-bottom .admin-sidebar-logout-form {
            margin: 0 !important;
            padding: 0 !important;
        }

        .admin-sidebar-bottom .admin-sidebar-logout-post-button,
        .admin-sidebar-bottom .admin-sidebar-logout-fixed {
            width: 100% !important;
            margin: 0 !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom {
            padding: 10px 8px 12px !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom .admin-sidebar-compact-toggle {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            margin: 0 auto 10px !important;
            padding: 0 !important;
            border-radius: 14px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom .admin-sidebar-logout-form {
            display: flex !important;
            justify-content: center !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom .admin-sidebar-logout-post-button,
        body.admin-sidebar-compact .admin-sidebar-bottom .admin-sidebar-logout-fixed {
            width: 48px !important;
            height: 48px !important;
            min-width: 48px !important;
            min-height: 48px !important;
            max-width: 48px !important;
            padding: 0 !important;
            margin: 0 auto !important;
            border-radius: 16px !important;
        }

        body.admin-sidebar-compact .admin-sidebar-bottom .admin-sidebar-logout-fixed-text {
            display: none !important;
        }
    }

    @media (max-width: 768px) {
        .sidebar,
        .admin-sidebar,
        aside {
            height: 100dvh !important;
            max-height: 100dvh !important;
            overflow: hidden !important;
            display: flex !important;
            flex-direction: column !important;
        }

        .admin-sidebar-scroll-area {
            flex: 1 1 auto !important;
            min-height: 0 !important;
            overflow-y: auto !important;
            overflow-x: hidden !important;
            -webkit-overflow-scrolling: touch;
        }

        .admin-sidebar-bottom {
            flex: 0 0 auto !important;
            margin-top: 0 !important;
            padding: 10px 10px calc(12px + env(safe-area-inset-bottom, 0px)) !important;
            background: #111827 !important;
            border-top: 1px solid rgba(255,255,255,.10) !important;
        }
    }
</style>
<!-- sidebar-layout-stability-style-end -->
<!-- admin-logs-menu-style-start -->
<style>
    .admin-logs-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .admin-logs-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- admin-logs-menu-style-end -->
<!-- theme-presets-menu-style-start -->
<style>
    .theme-presets-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .theme-presets-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- theme-presets-menu-style-end -->
<!-- admin-backups-menu-style-start -->
<style>
    .admin-backups-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .admin-backups-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- admin-backups-menu-style-end -->
<!-- admin-seo-checks-menu-style-start -->
<style>
    .admin-seo-checks-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .admin-seo-checks-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- admin-seo-checks-menu-style-end -->
<!-- content-versions-menu-style-start -->
<style>
    .content-versions-menu-link {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 11px 14px;
        border-radius: 12px;
        color: inherit;
        text-decoration: none;
        font-weight: 700;
        margin: 4px 10px;
    }

    .content-versions-menu-link:hover {
        background: rgba(255,255,255,.08);
    }
</style>
<!-- content-versions-menu-style-end -->
</head>
<body>
<!-- setup-checklist-banner-start -->
@php
    $setupChecklistCompleted = file_exists(storage_path('app/setup_checklist_completed.flag'));
    $setupChecklistPage = request()->is('admin/setup-checklist*');
@endphp

@if(!$setupChecklistCompleted && !$setupChecklistPage && request()->is('admin*'))
    <div class="setup-checklist-install-banner">
        <div>
            <strong>Kurulum checklist henüz tamamlandı olarak işaretlenmemiş.</strong>
            İlk kurulum ve müşteri teslimi öncesinde kontrol listesini inceleyin.
        </div>

        <a href="{{ url('/admin/setup-checklist') }}">Checklist’i Aç</a>
    </div>
@endif
<!-- setup-checklist-banner-end -->
<div class="admin-shell">
    <aside class="sidebar">
        <div class="brand">
            {{ setting('site_name', 'Corporate CMS') }}<span>.</span>
        </div>

        <div class="nav-title">Panel</div>
        <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">Dashboard</a>

        <div class="nav-title">İçerik Yönetimi</div>
        <a href="{{ route('admin.pages.index') }}" class="nav-link {{ request()->routeIs('admin.pages.*') ? 'active' : '' }}">Sayfalar</a>
        <a href="{{ route('admin.services.index') }}" class="nav-link {{ request()->routeIs('admin.services.*') ? 'active' : '' }}">Hizmetler</a>
        <a href="{{ route('admin.post-categories.index') }}" class="nav-link {{ request()->routeIs('admin.post-categories.*') ? 'active' : '' }}">Blog Kategorileri</a>
        <a href="{{ route('admin.posts.index') }}" class="nav-link {{ request()->routeIs('admin.posts.*') ? 'active' : '' }}">Blog Yazıları</a>
        <a href="{{ route('admin.sliders.index') }}" class="nav-link {{ request()->routeIs('admin.sliders.*') ? 'active' : '' }}">Slider</a>
        <a href="{{ route('admin.team-members.index') }}" class="nav-link {{ request()->routeIs('admin.team-members.*') ? 'active' : '' }}">Ekip Üyeleri</a>

        <div class="nav-title">Sistem</div>
        <a href="{{ route('admin.menus.index') }}" class="nav-link {{ request()->routeIs('admin.menus.*') ? 'active' : '' }}">Menü Yönetimi</a>
        <a href="{{ route('admin.media.index') }}" class="nav-link {{ request()->routeIs('admin.media.*') ? 'active' : '' }}">Medya Yönetimi</a>
        <a href="{{ route('admin.contact-messages.index') }}" class="nav-link {{ request()->routeIs('admin.contact-messages.*') ? 'active' : '' }}">İletişim Mesajları</a>
        <a href="{{ route('admin.settings.index') }}" class="nav-link {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}">Site Ayarları</a>
        <a href="{{ route('home') }}" target="_blank" class="nav-link">Siteyi Görüntüle</a>

        <form method="post" action="{{ route('admin.logout') }}" style="margin-top:18px;">
            @csrf
            <button type="submit" class="btn btn-danger" style="width:100%;">Çıkış Yap</button>
        </form>
    <a href="{{ url('/admin/usage-guide') }}" class="usage-guide-menu-link">Kullanım Kılavuzu</a>
<a href="{{ url('/admin/setup-checklist') }}" class="setup-checklist-menu-link">Kurulum Checklist</a>
<a href="{{ url('/admin/users') }}" class="admin-users-menu-link">Admin Kullanıcıları</a>
<a href="{{ url('/admin/login-attempts') }}" class="login-attempts-menu-link">Login Denemeleri</a>
<a href="{{ url('/admin/theme-settings') }}" class="theme-settings-menu-link">Tema Ayarları</a>
<a href="{{ url('/admin/logs') }}" class="admin-logs-menu-link">Loglar</a>
<a href="{{ url('/admin/theme-presets') }}" class="theme-presets-menu-link">Tema Presetleri</a>
<a href="{{ url('/admin/backups') }}" class="admin-backups-menu-link">Yedekleme</a>
<a href="{{ url('/admin/seo-checks') }}" class="admin-seo-checks-menu-link">SEO Kontrol</a>
<a href="{{ url('/admin/content-versions') }}" class="content-versions-menu-link">Sürüm Geçmişi</a>
</aside>

    <div class="main">
        <header class="topbar">
            <div class="topbar-title">@yield('topbar_title', 'Admin Panel')</div>
            <div class="user-info">
                {{ session('admin_user_name') }} · {{ session('admin_user_email') }}
            </div>
        </header>

        <section class="content">
            @if(session('success'))
                <div class="alert-success">{{ session('success') }}</div>
            @endif

            @if(session('error'))
                <div class="alert-error">{{ session('error') }}</div>
            @endif

            @yield('content')
        </section>
    </div>
</div>

@stack('scripts')
<!-- admin-responsive-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var hasSidebar = document.querySelector('.sidebar, .admin-sidebar');

        if (!hasSidebar) {
            return;
        }

        var existingButton = document.querySelector('.admin-mobile-toggle');

        if (!existingButton) {
            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'admin-mobile-toggle';
            button.setAttribute('aria-label', 'Menüyü aç/kapat');
            button.innerHTML = '☰';
            document.body.appendChild(button);
        }

        var toggle = document.querySelector('.admin-mobile-toggle');

        if (!toggle) {
            return;
        }

        toggle.addEventListener('click', function () {
            document.body.classList.toggle('admin-menu-open');
        });

        document.querySelectorAll('.sidebar a, .admin-sidebar a').forEach(function (link) {
            link.addEventListener('click', function () {
                document.body.classList.remove('admin-menu-open');
            });
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                document.body.classList.remove('admin-menu-open');
            }
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth > 991) {
                document.body.classList.remove('admin-menu-open');
            }
        });
    });
</script>
<!-- admin-responsive-script-end -->
<!-- content-editor-script-start -->
<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        if (typeof ClassicEditor === 'undefined') {
            return;
        }

        document.querySelectorAll('textarea.rich-editor').forEach(function (textarea) {
            if (textarea.dataset.editorInitialized === '1') {
                return;
            }

            textarea.dataset.editorInitialized = '1';

            ClassicEditor
                .create(textarea, {
                    toolbar: {
                        items: [
                            'heading',
                            '|',
                            'bold',
                            'italic',
                            'link',
                            '|',
                            'bulletedList',
                            'numberedList',
                            '|',
                            'blockQuote',
                            'insertTable',
                            '|',
                            'undo',
                            'redo'
                        ]
                    },
                    heading: {
                        options: [
                            { model: 'paragraph', title: 'Paragraf', class: 'ck-heading_paragraph' },
                            { model: 'heading2', view: 'h2', title: 'Başlık 2', class: 'ck-heading_heading2' },
                            { model: 'heading3', view: 'h3', title: 'Başlık 3', class: 'ck-heading_heading3' },
                            { model: 'heading4', view: 'h4', title: 'Başlık 4', class: 'ck-heading_heading4' }
                        ]
                    },
                    table: {
                        contentToolbar: [
                            'tableColumn',
                            'tableRow',
                            'mergeTableCells'
                        ]
                    }
                })
                .then(function (editor) {
                    if (textarea.form) {
                        textarea.form.addEventListener('submit', function () {
                            textarea.value = editor.getData();
                        });
                    }
                })
                .catch(function (error) {
                    console.error('Editor başlatılamadı:', error);
                });
        });
    });
</script>
<!-- content-editor-script-end -->
<!-- media-picker-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var targetInput = null;

        var supportedNames = [
            'image',
            'photo',
            'cover_image',
            'featured_image',
            'slider_image',
            'background_image',
            'logo',
            'header_logo',
            'footer_logo',
            'favicon',
            'default_og_image',
            'og_image',
            'file',
            'document',
            'attachment'
        ];

        function isSupportedInput(input) {
            if (!input || input.dataset.mediaPickerBound === '1') {
                return false;
            }

            var name = input.getAttribute('name') || '';
            var id = input.getAttribute('id') || '';

            if (supportedNames.indexOf(name) !== -1 || supportedNames.indexOf(id) !== -1) {
                return true;
            }

            if (name.match(/image|logo|photo|file|document|attachment|favicon|og/i)) {
                return true;
            }

            return false;
        }

        function createModal() {
            if (document.getElementById('mediaPickerModal')) {
                return;
            }

            var modal = document.createElement('div');
            modal.className = 'media-picker-modal';
            modal.id = 'mediaPickerModal';
            modal.innerHTML = '' +
                '<div class="media-picker-backdrop" data-media-close="1"></div>' +
                '<div class="media-picker-dialog">' +
                    '<div class="media-picker-top">' +
                        '<span>Medya Seç</span>' +
                        '<button type="button" class="media-picker-close" data-media-close="1">Kapat</button>' +
                    '</div>' +
                    '<iframe class="media-picker-frame" id="mediaPickerFrame" src="about:blank"></iframe>' +
                '</div>';

            document.body.appendChild(modal);

            modal.querySelectorAll('[data-media-close]').forEach(function (el) {
                el.addEventListener('click', closeModal);
            });
        }

        function openModal(input) {
            createModal();

            targetInput = input;

            var modal = document.getElementById('mediaPickerModal');
            var frame = document.getElementById('mediaPickerFrame');

            frame.src = '{{ url('/admin/media-picker') }}';
            modal.classList.add('is-open');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            var modal = document.getElementById('mediaPickerModal');
            var frame = document.getElementById('mediaPickerFrame');

            if (modal) {
                modal.classList.remove('is-open');
            }

            if (frame) {
                frame.src = 'about:blank';
            }

            document.body.style.overflow = '';
            targetInput = null;
        }

        function previewInput(input) {
            var value = input.value || '';

            if (!value) {
                alert('Önizlenecek dosya yolu yok.');
                return;
            }

            var url = value;

            if (!/^https?:\/\//i.test(value) && !value.startsWith('/')) {
                url = '{{ url('/') }}/' + value.replace(/^\/+/, '');
            }

            window.open(url, '_blank');
        }

        document.querySelectorAll('input[type="text"], input[type="url"]').forEach(function (input) {
            if (!isSupportedInput(input)) {
                return;
            }

            input.dataset.mediaPickerBound = '1';

            var group = document.createElement('div');
            group.className = 'media-picker-button-group';

            var selectButton = document.createElement('button');
            selectButton.type = 'button';
            selectButton.className = 'media-picker-trigger';
            selectButton.textContent = 'Medyadan Seç';
            selectButton.addEventListener('click', function () {
                openModal(input);
            });

            var previewButton = document.createElement('button');
            previewButton.type = 'button';
            previewButton.className = 'media-preview-trigger';
            previewButton.textContent = 'Önizle';
            previewButton.addEventListener('click', function () {
                previewInput(input);
            });

            group.appendChild(selectButton);
            group.appendChild(previewButton);

            input.insertAdjacentElement('afterend', group);
        });

        window.addEventListener('message', function (event) {
            if (event.origin !== window.location.origin) {
                return;
            }

            if (!event.data || event.data.type !== 'media-selected') {
                return;
            }

            if (!targetInput) {
                return;
            }

            targetInput.value = event.data.path || '';
            targetInput.dispatchEvent(new Event('input', { bubbles: true }));
            targetInput.dispatchEvent(new Event('change', { bubbles: true }));

            closeModal();
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                closeModal();
            }
        });
    });
</script>
<!-- media-picker-script-end -->
<!-- admin-ui-polish-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('table').forEach(function (table) {
            if (table.closest('.table-wrap')) {
                return;
            }

            var wrapper = document.createElement('div');
            wrapper.className = 'table-wrap';

            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        });

        document.querySelectorAll('td').forEach(function (td) {
            var text = td.textContent.trim().toLowerCase();

            if (td.querySelector('.badge, .status-badge')) {
                return;
            }

            if (text === 'aktif' || text === 'active' || text === 'yayında') {
                td.innerHTML = '<span class="badge badge-success">' + td.textContent.trim() + '</span>';
            }

            if (text === 'pasif' || text === 'passive' || text === 'taslak') {
                td.innerHTML = '<span class="badge badge-danger">' + td.textContent.trim() + '</span>';
            }
        });

        document.querySelectorAll('form[onsubmit*="confirm"]').forEach(function (form) {
            form.dataset.hasConfirm = '1';
        });
    });
</script>
<!-- admin-ui-polish-script-end -->
<!-- auto-slug-v2-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function turkishToAscii(value) {
            var map = {
                'ş': 's', 'Ş': 's',
                'ı': 'i', 'İ': 'i',
                'ğ': 'g', 'Ğ': 'g',
                'ü': 'u', 'Ü': 'u',
                'ö': 'o', 'Ö': 'o',
                'ç': 'c', 'Ç': 'c'
            };

            return String(value || '').replace(/[şŞıİğĞüÜöÖçÇ]/g, function (char) {
                return map[char] || char;
            });
        }

        function slugify(value) {
            value = turkishToAscii(value);
            value = value.toLowerCase();
            value = value.replace(/&/g, ' ve ');
            value = value.replace(/['’"`´]/g, '');
            value = value.replace(/[^a-z0-9]+/g, '-');
            value = value.replace(/^-+|-+$/g, '');
            value = value.replace(/-{2,}/g, '-');

            return value;
        }

        function findSlugInputs() {
            var inputs = [];

            document.querySelectorAll('input').forEach(function (input) {
                var name = (input.getAttribute('name') || '').toLowerCase();
                var id = (input.getAttribute('id') || '').toLowerCase();

                if (name === 'slug' || id === 'slug' || name.indexOf('slug') !== -1 || id.indexOf('slug') !== -1) {
                    inputs.push(input);
                }
            });

            return inputs;
        }

        function labelTextFor(input) {
            var id = input.getAttribute('id');

            if (id) {
                var label = document.querySelector('label[for="' + id + '"]');

                if (label) {
                    return label.textContent.trim().toLowerCase();
                }
            }

            var parent = input.closest('div');

            if (parent) {
                var labelInParent = parent.querySelector('label');

                if (labelInParent) {
                    return labelInParent.textContent.trim().toLowerCase();
                }
            }

            return '';
        }

        function findTitleInputNear(slugInput) {
            var form = slugInput.closest('form') || document;

            var directSelectors = [
                'input[name="title"]',
                'input[id="title"]',
                'input[name="name"]',
                'input[id="name"]',
                'input[name="heading"]',
                'input[id="heading"]',
                'input[name="page_title"]',
                'input[name="service_title"]',
                'input[name="post_title"]'
            ];

            for (var i = 0; i < directSelectors.length; i++) {
                var found = form.querySelector(directSelectors[i]);

                if (found && found !== slugInput) {
                    return found;
                }
            }

            var textInputs = Array.prototype.slice.call(form.querySelectorAll('input[type="text"], input:not([type])'));

            for (var j = 0; j < textInputs.length; j++) {
                var input = textInputs[j];

                if (input === slugInput) {
                    continue;
                }

                var name = (input.getAttribute('name') || '').toLowerCase();
                var id = (input.getAttribute('id') || '').toLowerCase();
                var label = labelTextFor(input);

                if (
                    name.indexOf('title') !== -1 ||
                    id.indexOf('title') !== -1 ||
                    name.indexOf('name') !== -1 ||
                    id.indexOf('name') !== -1 ||
                    label.indexOf('başlık') !== -1 ||
                    label.indexOf('baslik') !== -1 ||
                    label.indexOf('ad') !== -1 ||
                    label.indexOf('adı') !== -1 ||
                    label.indexOf('adi') !== -1 ||
                    label.indexOf('title') !== -1
                ) {
                    return input;
                }
            }

            for (var k = 0; k < textInputs.length; k++) {
                var candidate = textInputs[k];

                if (candidate === slugInput) {
                    continue;
                }

                var candidateName = (candidate.getAttribute('name') || '').toLowerCase();
                var candidateId = (candidate.getAttribute('id') || '').toLowerCase();

                if (
                    candidateName.indexOf('url') !== -1 ||
                    candidateId.indexOf('url') !== -1 ||
                    candidateName.indexOf('image') !== -1 ||
                    candidateId.indexOf('image') !== -1 ||
                    candidateName.indexOf('logo') !== -1 ||
                    candidateId.indexOf('logo') !== -1
                ) {
                    continue;
                }

                return candidate;
            }

            return null;
        }

        function guessPreviewPrefix() {
            var path = window.location.pathname;

            if (path.indexOf('/admin/services') !== -1) {
                return '/hizmetler/';
            }

            if (path.indexOf('/admin/posts') !== -1) {
                return '/blog/';
            }

            if (path.indexOf('/admin/post-categories') !== -1) {
                return '/blog/kategori/';
            }

            if (path.indexOf('/admin/team-members') !== -1) {
                return '/ekibimiz/';
            }

            return '/';
        }

        function updatePreview(slugInput, previewEl) {
            if (!previewEl) {
                return;
            }

            var slug = slugInput.value || '';

            if (!slug) {
                previewEl.innerHTML = 'Önizleme: <code>-</code>';
                return;
            }

            previewEl.innerHTML = 'Önizleme: <code>' + window.location.origin + guessPreviewPrefix() + slug + '</code>';
        }

        function setupSlugInput(slugInput) {
            if (!slugInput || slugInput.dataset.autoSlugV2Ready === '1') {
                return;
            }

            var titleInput = findTitleInputNear(slugInput);

            if (!titleInput) {
                console.warn('Slug aracı başlık alanı bulamadı:', slugInput);
                return;
            }

            slugInput.dataset.autoSlugV2Ready = '1';

            var isEditPage = String(slugInput.value || '').trim() !== '';
            var locked = isEditPage;

            var preview = document.createElement('span');
            preview.className = 'auto-slug-preview';

            var help = document.createElement('small');
            help.className = 'auto-slug-help';
            help.textContent = 'Başlıktan otomatik slug üretir. Türkçe karakterleri dönüştürür, boşlukları tire yapar. İstersen slug alanını elle düzenleyebilirsin.';

            var tools = document.createElement('div');
            tools.className = 'auto-slug-tools';

            var refreshButton = document.createElement('button');
            refreshButton.type = 'button';
            refreshButton.className = 'auto-slug-refresh';
            refreshButton.textContent = 'Slug Yenile';

            var lockButton = document.createElement('button');
            lockButton.type = 'button';
            lockButton.className = 'auto-slug-lock';

            var status = document.createElement('span');
            status.className = 'auto-slug-status';

            function renderStatus() {
                if (locked) {
                    lockButton.textContent = 'Kilidi Aç';
                    status.textContent = 'Slug kilitli';
                    status.classList.add('is-locked');
                } else {
                    lockButton.textContent = 'Slug Kilitle';
                    status.textContent = 'Otomatik slug aktif';
                    status.classList.remove('is-locked');
                }

                updatePreview(slugInput, preview);
            }

            function generateSlug(force) {
                if (locked && !force) {
                    return;
                }

                var value = slugify(titleInput.value);

                if (!value) {
                    return;
                }

                slugInput.value = value;
                slugInput.dispatchEvent(new Event('input', { bubbles: true }));
                slugInput.dispatchEvent(new Event('change', { bubbles: true }));
                updatePreview(slugInput, preview);
            }

            refreshButton.addEventListener('click', function () {
                var value = slugify(titleInput.value);

                if (!value) {
                    alert('Slug üretmek için önce başlık/ad alanını doldur.');
                    return;
                }

                slugInput.value = value;
                slugInput.dispatchEvent(new Event('input', { bubbles: true }));
                slugInput.dispatchEvent(new Event('change', { bubbles: true }));
                updatePreview(slugInput, preview);
            });

            lockButton.addEventListener('click', function () {
                locked = !locked;
                renderStatus();
            });

            titleInput.addEventListener('input', function () {
                if (!locked && !slugInput.value) {
                    generateSlug(false);
                }
            });

            titleInput.addEventListener('blur', function () {
                if (!locked && !slugInput.value) {
                    generateSlug(false);
                }
            });

            slugInput.addEventListener('input', function () {
                var normalized = slugify(slugInput.value);

                if (slugInput.value !== normalized) {
                    slugInput.value = normalized;
                }

                updatePreview(slugInput, preview);
            });

            var form = slugInput.closest('form');

            if (form) {
                form.addEventListener('submit', function () {
                    if (!slugInput.value) {
                        slugInput.value = slugify(titleInput.value);
                    } else {
                        slugInput.value = slugify(slugInput.value);
                    }
                });
            }

            slugInput.insertAdjacentElement('afterend', preview);
            preview.insertAdjacentElement('afterend', help);
            help.insertAdjacentElement('afterend', tools);

            tools.appendChild(refreshButton);
            tools.appendChild(lockButton);
            tools.appendChild(status);

            if (!isEditPage && titleInput.value && !slugInput.value) {
                generateSlug(true);
            }

            renderStatus();
        }

        var slugInputs = findSlugInputs();

        slugInputs.forEach(function (slugInput) {
            setupSlugInput(slugInput);
        });
    });
</script>
<!-- auto-slug-v2-script-end -->
<!-- duplicate-content-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var path = window.location.pathname;
        var type = null;

        if (path.indexOf('/admin/pages') !== -1) {
            type = 'pages';
        }

        if (path.indexOf('/admin/services') !== -1) {
            type = 'services';
        }

        if (path.indexOf('/admin/posts') !== -1) {
            type = 'posts';
        }

        if (!type) {
            return;
        }

        if (path.indexOf('/create') !== -1 || path.indexOf('/edit') !== -1) {
            return;
        }

        var csrfToken = '{{ csrf_token() }}';

        function extractIdFromEditHref(href) {
            var pattern = new RegExp('/admin/' + type + '/([0-9]+)/edit');
            var match = href.match(pattern);

            if (match && match[1]) {
                return match[1];
            }

            return null;
        }

        document.querySelectorAll('a[href*="/admin/' + type + '/"][href$="/edit"]').forEach(function (editLink) {
            var id = extractIdFromEditHref(editLink.getAttribute('href') || '');

            if (!id) {
                return;
            }

            var parent = editLink.parentElement;

            if (!parent || parent.querySelector('.duplicate-content-btn[data-id="' + id + '"]')) {
                return;
            }

            var form = document.createElement('form');
            form.method = 'POST';
            form.action = '{{ url('/admin/duplicate') }}/' + type + '/' + id;
            form.style.display = 'inline-flex';
            form.style.margin = '0';

            var csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = '_token';
            csrfInput.value = csrfToken;

            var button = document.createElement('button');
            button.type = 'submit';
            button.className = 'duplicate-content-btn';
            button.dataset.id = id;
            button.textContent = 'Kopyala';

            form.addEventListener('submit', function (event) {
                if (!confirm('Bu kaydı kopyalamak istediğine emin misin?')) {
                    event.preventDefault();
                }
            });

            form.appendChild(csrfInput);
            form.appendChild(button);

            editLink.insertAdjacentElement('afterend', form);
        });
    });
</script>
<!-- duplicate-content-script-end -->
<!-- preview-content-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var path = window.location.pathname;
        var type = null;

        if (path.indexOf('/admin/pages') !== -1) {
            type = 'pages';
        }

        if (path.indexOf('/admin/services') !== -1) {
            type = 'services';
        }

        if (path.indexOf('/admin/posts') !== -1) {
            type = 'posts';
        }

        if (!type) {
            return;
        }

        if (path.indexOf('/create') !== -1 || path.indexOf('/edit') !== -1) {
            return;
        }

        function extractIdFromEditHref(href) {
            var pattern = new RegExp('/admin/' + type + '/([0-9]+)/edit');
            var match = href.match(pattern);

            if (match && match[1]) {
                return match[1];
            }

            return null;
        }

        document.querySelectorAll('a[href*="/admin/' + type + '/"][href$="/edit"]').forEach(function (editLink) {
            var href = editLink.getAttribute('href') || '';
            var id = extractIdFromEditHref(href);

            if (!id) {
                return;
            }

            var parent = editLink.parentElement;

            if (!parent || parent.querySelector('.preview-content-btn[data-id="' + id + '"]')) {
                return;
            }

            var previewLink = document.createElement('a');
            previewLink.href = '{{ url('/admin/preview') }}/' + type + '/' + id;
            previewLink.target = '_blank';
            previewLink.rel = 'noopener';
            previewLink.className = 'preview-content-btn';
            previewLink.dataset.id = id;
            previewLink.textContent = 'Önizle';

            editLink.insertAdjacentElement('afterend', previewLink);
        });
    });
</script>
<!-- preview-content-script-end -->
<!-- admin-sidebar-ui-upgrade-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

        if (!sidebar || sidebar.dataset.sidebarUpgraded === '1') {
            return;
        }

        sidebar.dataset.sidebarUpgraded = '1';

        var allLinks = Array.prototype.slice.call(sidebar.querySelectorAll('a[href]'));

        function normalizeText(text) {
            return String(text || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();
        }

        function getIcon(text, href) {
            text = normalizeText(text);
            href = String(href || '').toLowerCase();

            if (text.includes('dashboard')) return '🏠';
            if (text.includes('sayfa')) return '📄';
            if (text.includes('hizmet')) return '🧩';
            if (text.includes('blog kategori')) return '🏷️';
            if (text.includes('blog')) return '✍️';
            if (text.includes('slider')) return '🖼️';
            if (text.includes('ekip') ||
                text.includes('iletişim') ||
                text.includes('iletisim')) return '👥';
            if (text.includes('menü') || text.includes('menu')) return '🧭';
            if (text.includes('medya')) return '🗂️';
            if (text.includes('iletişim') || text.includes('iletisim')) return '✉️';
            if (text.includes('ayar')) return '⚙️';
            if (text.includes('siteyi')) return '🌐';
            if (text.includes('kullanım') || text.includes('kullanim')) return '📘';
            if (text.includes('kurulum')) return '✅';
            if (text.includes('admin kullanıcı') || text.includes('admin kullanici')) return '🔐';
            if (text.includes('çıkış') || text.includes('cikis') || href.includes('logout')) return '🚪';

            return '•';
        }

        function getGroup(text, href) {
            text = normalizeText(text);
            href = String(href || '').toLowerCase();

            if (text.includes('dashboard')) return 'Panel';

            if (
                text.includes('sayfa') ||
                text.includes('hizmet') ||
                text.includes('blog') ||
                text.includes('slider') ||
                text.includes('ekip') ||
                text.includes('iletişim') ||
                text.includes('iletisim') ||
                text.includes('iletişim') ||
                text.includes('iletisim')
            ) {
                return 'İçerik Yönetimi';
            }

            if (
                text.includes('menü') ||
                text.includes('menu') ||
                text.includes('medya') ||
                text.includes('ayar')
            ) {
                return 'Sistem';
            }

            if (
                text.includes('kullanım') ||
                text.includes('kullanim') ||
                text.includes('kurulum') ||
                text.includes('checklist')
            ) {
                return 'Dokümantasyon';
            }

            if (
                text.includes('admin kullanıcı') ||
                text.includes('admin kullanici') ||
                text.includes('siteyi') ||
                text.includes('çıkış') ||
                text.includes('cikis') ||
                href.includes('logout')
            ) {
                return 'Yönetim';
            }

            return 'Diğer';
        }

        function isLogoutLink(link) {
            var text = normalizeText(link.textContent);
            var href = String(link.getAttribute('href') || '').toLowerCase();

            return text.includes('çıkış') || text.includes('cikis') || href.includes('logout');
        }

        function getCleanTitle() {
            var candidates = [
                document.querySelector('meta[name="application-name"]'),
                document.querySelector('meta[property="og:site_name"]')
            ];

            for (var i = 0; i < candidates.length; i++) {
                if (candidates[i] && candidates[i].getAttribute('content')) {
                    return candidates[i].getAttribute('content');
                }
            }

            return 'Yönetim Paneli';
        }

        var groups = {};
        var groupOrder = ['Panel', 'İçerik Yönetimi', 'Sistem', 'Dokümantasyon', 'Yönetim', 'Diğer'];

        allLinks.forEach(function (link) {
            var text = link.textContent.trim();
            var href = link.getAttribute('href') || '';

            if (!text || href === '#') {
                return;
            }

            var group = getGroup(text, href);

            if (!groups[group]) {
                groups[group] = [];
            }

            groups[group].push({
                text: text,
                href: href,
                target: link.getAttribute('target'),
                logout: isLogoutLink(link),
                original: link
            });
        });

        sidebar.innerHTML = '';

        var brand = document.createElement('div');
        brand.className = 'admin-sidebar-brand';
        brand.innerHTML = '' +
            '<h2 class="admin-sidebar-brand-title">' + getCleanTitle() + '</h2>' +
            '<span class="admin-sidebar-brand-subtitle">Admin Panel</span>';

        sidebar.appendChild(brand);

        groupOrder.forEach(function (groupName) {
            var items = groups[groupName];

            if (!items || !items.length) {
                return;
            }

            var section = document.createElement('div');
            section.className = 'admin-sidebar-section';

            var titleButton = document.createElement('button');
            titleButton.type = 'button';
            titleButton.className = 'admin-sidebar-section-title';
            titleButton.innerHTML = '<span>' + groupName + '</span>';

            var linksWrapper = document.createElement('div');
            linksWrapper.className = 'admin-sidebar-section-links';

            titleButton.addEventListener('click', function () {
                section.classList.toggle('is-collapsed');

                try {
                    localStorage.setItem(
                        'adminSidebarCollapsed_' + groupName,
                        section.classList.contains('is-collapsed') ? '1' : '0'
                    );
                } catch (e) {}
            });

            try {
                if (localStorage.getItem('adminSidebarCollapsed_' + groupName) === '1') {
                    section.classList.add('is-collapsed');
                }
            } catch (e) {}

            items.forEach(function (item) {
                var link = document.createElement('a');
                link.href = item.href;
                link.className = 'admin-sidebar-link';

                if (item.target) {
                    link.target = item.target;
                    link.rel = 'noopener';
                }

                if (item.logout) {
                    link.classList.add('admin-sidebar-logout');
                }

                var currentPath = window.location.pathname.replace(/\/+$/, '');
                var linkPath;

                try {
                    linkPath = new URL(item.href, window.location.origin).pathname.replace(/\/+$/, '');
                } catch (e) {
                    linkPath = item.href;
                }

                if (linkPath && linkPath !== '/' && currentPath.indexOf(linkPath) === 0) {
                    link.classList.add('is-active');
                }

                link.innerHTML = '' +
                    '<span class="admin-sidebar-link-icon">' + getIcon(item.text, item.href) + '</span>' +
                    '<span class="admin-sidebar-link-text">' + item.text + '</span>';

                linksWrapper.appendChild(link);
            });

            section.appendChild(titleButton);
            section.appendChild(linksWrapper);
            sidebar.appendChild(section);
        });

        var compactButton = document.createElement('button');
        compactButton.type = 'button';
        compactButton.className = 'admin-sidebar-compact-toggle';
        compactButton.innerHTML = '☰ <span>Daralt</span>';

        compactButton.addEventListener('click', function () {
            document.body.classList.toggle('admin-sidebar-compact');

            try {
                localStorage.setItem(
                    'adminSidebarCompact',
                    document.body.classList.contains('admin-sidebar-compact') ? '1' : '0'
                );
            } catch (e) {}
        });

        try {
            if (localStorage.getItem('adminSidebarCompact') === '1') {
                document.body.classList.add('admin-sidebar-compact');
            }
        } catch (e) {}

        sidebar.appendChild(compactButton);
    });
</script>
<!-- admin-sidebar-ui-upgrade-script-end -->
<!-- admin-sidebar-experience-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

        if (!sidebar) {
            return;
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function waitForUpgradedSidebar(callback, attempt) {
            attempt = attempt || 0;

            if (sidebar.querySelector('.admin-sidebar-section') || attempt > 20) {
                callback();
                return;
            }

            setTimeout(function () {
                waitForUpgradedSidebar(callback, attempt + 1);
            }, 100);
        }

        waitForUpgradedSidebar(function () {
            if (sidebar.dataset.sidebarExperienceReady === '1') {
                return;
            }

            sidebar.dataset.sidebarExperienceReady = '1';

            /*
            |--------------------------------------------------------------------------
            | 1. Arama kutusu
            |--------------------------------------------------------------------------
            */

            var brand = sidebar.querySelector('.admin-sidebar-brand');
            var firstSection = sidebar.querySelector('.admin-sidebar-section');

            if (!sidebar.querySelector('.admin-sidebar-search-wrap')) {
                var searchWrap = document.createElement('div');
                searchWrap.className = 'admin-sidebar-search-wrap';

                var searchInput = document.createElement('input');
                searchInput.type = 'search';
                searchInput.className = 'admin-sidebar-search';
                searchInput.placeholder = 'Menüde ara...';
                searchInput.autocomplete = 'off';

                searchWrap.appendChild(searchInput);

                if (brand && brand.nextSibling) {
                    sidebar.insertBefore(searchWrap, brand.nextSibling);
                } else if (firstSection) {
                    sidebar.insertBefore(searchWrap, firstSection);
                } else {
                    sidebar.insertBefore(searchWrap, sidebar.firstChild);
                }

                var emptyState = document.createElement('div');
                emptyState.className = 'admin-sidebar-search-empty';
                emptyState.textContent = 'Aradığın menü bulunamadı. Menü de naz yapıyor olabilir.';
                sidebar.insertBefore(emptyState, searchWrap.nextSibling);

                searchInput.addEventListener('input', function () {
                    var query = normalizeText(searchInput.value);
                    var visibleCount = 0;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var sectionTitle = normalizeText(section.querySelector('.admin-sidebar-section-title') ? section.querySelector('.admin-sidebar-section-title').textContent : '');
                        var links = Array.prototype.slice.call(section.querySelectorAll('.admin-sidebar-link'));
                        var sectionHasVisibleLink = false;

                        links.forEach(function (link) {
                            var linkText = normalizeText(link.textContent);
                            var linkHref = normalizeText(link.getAttribute('href') || '');
                            var matched = !query || linkText.indexOf(query) !== -1 || linkHref.indexOf(query) !== -1 || sectionTitle.indexOf(query) !== -1;

                            link.classList.toggle('is-hidden-by-search', !matched);

                            if (matched) {
                                sectionHasVisibleLink = true;
                                visibleCount++;
                            }
                        });

                        section.classList.toggle('is-hidden-by-search', !sectionHasVisibleLink);

                        if (query && sectionHasVisibleLink) {
                            section.classList.remove('is-collapsed');
                        } else if (!query && section.dataset.defaultCollapsed === '1') {
                            section.classList.add('is-collapsed');
                        }
                    });

                    emptyState.classList.toggle('is-visible', !!query && visibleCount === 0);
                });
            }

            /*
            |--------------------------------------------------------------------------
            | 2. Dokümantasyon ve Yönetim varsayılan kapalı
            |--------------------------------------------------------------------------
            */

            sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                var titleEl = section.querySelector('.admin-sidebar-section-title');
                var title = normalizeText(titleEl ? titleEl.textContent : '');

                if (title.indexOf('dokümantasyon') !== -1 || title.indexOf('dokumantasyon') !== -1 || title.indexOf('yönetim') !== -1 || title.indexOf('yonetim') !== -1) {
                    section.classList.add('is-default-collapsed');
                    section.dataset.defaultCollapsed = '1';

                    try {
                        var storageKey = 'adminSidebarCollapsed_' + (titleEl ? titleEl.textContent.trim() : '');
                        var userPreference = localStorage.getItem(storageKey);

                        if (userPreference === null) {
                            section.classList.add('is-collapsed');
                        }
                    } catch (e) {
                        section.classList.add('is-collapsed');
                    }
                }
            });

            /*
            |--------------------------------------------------------------------------
            | 3. Çıkış butonunu en alta al
            |--------------------------------------------------------------------------
            */

            var logoutLink = sidebar.querySelector('.admin-sidebar-logout');

            if (logoutLink && !sidebar.querySelector('.admin-sidebar-bottom')) {
                var bottom = document.createElement('div');
                bottom.className = 'admin-sidebar-bottom';

                logoutLink.parentNode.removeChild(logoutLink);
                bottom.appendChild(logoutLink);
                sidebar.appendChild(bottom);
            }

            /*
            |--------------------------------------------------------------------------
            | 4. Aktif menü vurgusunu netleştir
            |--------------------------------------------------------------------------
            */

            var currentPath = window.location.pathname.replace(/\/+$/, '');
            var bestMatch = null;
            var bestLength = 0;

            sidebar.querySelectorAll('.admin-sidebar-link[href]').forEach(function (link) {
                link.classList.remove('is-active');

                var href = link.getAttribute('href') || '';
                var linkPath = '';

                try {
                    linkPath = new URL(href, window.location.origin).pathname.replace(/\/+$/, '');
                } catch (e) {
                    linkPath = href.replace(/\/+$/, '');
                }

                if (!linkPath || linkPath === '/') {
                    return;
                }

                if (currentPath === linkPath || currentPath.indexOf(linkPath + '/') === 0) {
                    if (linkPath.length > bestLength) {
                        bestMatch = link;
                        bestLength = linkPath.length;
                    }
                }
            });

            if (bestMatch) {
                bestMatch.classList.add('is-active');

                var activeSection = bestMatch.closest('.admin-sidebar-section');

                if (activeSection) {
                    activeSection.classList.remove('is-collapsed');
                }
            }
        });
    });
</script>
<!-- admin-sidebar-experience-script-end -->

<!-- logout-post-button-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 20)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar || sidebar.dataset.logoutPostReady === '1') {
                return;
            }

            sidebar.dataset.logoutPostReady = '1';

            /*
            |--------------------------------------------------------------------------
            | Eski link/form logout elemanlarını temizle
            |--------------------------------------------------------------------------
            */

            sidebar.querySelectorAll('.admin-sidebar-logout-fixed, .admin-sidebar-logout-form').forEach(function (item) {
                item.remove();
            });

            sidebar.querySelectorAll('a[href]').forEach(function (link) {
                var text = String(link.textContent || '').toLocaleLowerCase('tr-TR');
                var href = String(link.getAttribute('href') || '').toLowerCase();

                if (
                    text.indexOf('çıkış') !== -1 ||
                    text.indexOf('cikis') !== -1 ||
                    text.indexOf('logout') !== -1 ||
                    href.indexOf('logout') !== -1
                ) {
                    var parentSection = link.closest('.admin-sidebar-section');
                    link.remove();

                    if (parentSection && parentSection.querySelectorAll('a, button').length === 0) {
                        parentSection.remove();
                    }
                }
            });

            /*
            |--------------------------------------------------------------------------
            | Bottom alanı
            |--------------------------------------------------------------------------
            */

            var bottom = sidebar.querySelector('.admin-sidebar-bottom');

            if (!bottom) {
                bottom = document.createElement('div');
                bottom.className = 'admin-sidebar-bottom';
                sidebar.appendChild(bottom);
            }

            /*
            |--------------------------------------------------------------------------
            | POST logout form
            |--------------------------------------------------------------------------
            */

            var form = document.createElement('form');
            form.method = 'POST';
            form.action = '{{ url('/admin/logout') }}';
            form.className = 'admin-sidebar-logout-form';

            var csrf = document.createElement('input');
            csrf.type = 'hidden';
            csrf.name = '_token';
            csrf.value = '{{ csrf_token() }}';

            var button = document.createElement('button');
            button.type = 'submit';
            button.className = 'admin-sidebar-logout-post-button';
            button.innerHTML = ''
                + '<span class="admin-sidebar-logout-fixed-icon">🚪</span>'
                + '<span class="admin-sidebar-logout-fixed-text">Çıkış Yap</span>';

            form.addEventListener('submit', function (event) {
                if (!confirm('Panelden çıkış yapmak istiyor musun?')) {
                    event.preventDefault();
                }
            });

            form.appendChild(csrf);
            form.appendChild(button);
            bottom.appendChild(form);
        });
    });
</script>
<!-- logout-post-button-script-end -->

<!-- dashboard-card-title-fix-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var path = window.location.pathname;

        if (path.indexOf('/admin/dashboard') === -1 && path !== '/admin') {
            return;
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function cleanNumber(text) {
            var match = String(text || '').match(/[\d.,]+/);
            return match ? match[0] : '0';
        }

        function resolveCardMeta(rawText, index) {
            var text = normalizeText(rawText);

            if (text.indexOf('okunmamış') !== -1 || text.indexOf('okunmamis') !== -1 || text.indexOf('yanıt') !== -1 || text.indexOf('yanit') !== -1) {
                return {
                    title: 'Okunmamış Mesajlar',
                    hint: 'Yanıt bekleyen mesajlar',
                    icon: '🔔',
                    color: 'stat-red'
                };
            }

            if (text.indexOf('iletişim') !== -1 || text.indexOf('iletisim') !== -1 || text.indexOf('mesaj') !== -1) {
                return {
                    title: 'İletişim Mesajları',
                    hint: 'Toplam gelen mesaj',
                    icon: '✉️',
                    color: 'stat-slate'
                };
            }

            if (text.indexOf('medya') !== -1 || text.indexOf('dosya') !== -1 || text.indexOf('yüklenen') !== -1 || text.indexOf('yuklenen') !== -1) {
                return {
                    title: 'Medya Dosyaları',
                    hint: 'Yüklenen görsel ve dosyalar',
                    icon: '🗂️',
                    color: 'stat-pink'
                };
            }

            if (text.indexOf('ekip') !== -1 || text.indexOf('profil') !== -1) {
                return {
                    title: 'Ekip Üyeleri',
                    hint: 'Tanımlı ekip profilleri',
                    icon: '👥',
                    color: 'stat-cyan'
                };
            }

            if (text.indexOf('slider') !== -1) {
                return {
                    title: 'Slider',
                    hint: 'Ana sayfa slider kayıtları',
                    icon: '🖼️',
                    color: 'stat-orange'
                };
            }

            if (text.indexOf('blog') !== -1 || text.indexOf('yazı') !== -1 || text.indexOf('yazi') !== -1) {
                return {
                    title: 'Blog Yazıları',
                    hint: 'Yayınlanan blog içerikleri',
                    icon: '✍️',
                    color: 'stat-purple'
                };
            }

            if (text.indexOf('hizmet') !== -1) {
                return {
                    title: 'Hizmetler',
                    hint: 'Tanımlı hizmet kayıtları',
                    icon: '🧩',
                    color: 'stat-green'
                };
            }

            if (text.indexOf('sayfa') !== -1 || text.indexOf('içerik') !== -1 || text.indexOf('icerik') !== -1) {
                return {
                    title: 'Sayfalar',
                    hint: 'Yönetilen içerik sayfaları',
                    icon: '📄',
                    color: 'stat-blue'
                };
            }

            var defaults = [
                { title: 'Sayfalar', hint: 'Yönetilen içerik sayfaları', icon: '📄', color: 'stat-blue' },
                { title: 'Hizmetler', hint: 'Tanımlı hizmet kayıtları', icon: '🧩', color: 'stat-green' },
                { title: 'Blog Yazıları', hint: 'Yayınlanan blog içerikleri', icon: '✍️', color: 'stat-purple' },
                { title: 'Slider', hint: 'Ana sayfa slider kayıtları', icon: '🖼️', color: 'stat-orange' },
                { title: 'Ekip Üyeleri', hint: 'Tanımlı ekip profilleri', icon: '👥', color: 'stat-cyan' },
                { title: 'Medya Dosyaları', hint: 'Yüklenen görsel ve dosyalar', icon: '🗂️', color: 'stat-pink' },
                { title: 'İletişim Mesajları', hint: 'Toplam gelen mesaj', icon: '✉️', color: 'stat-slate' },
                { title: 'Okunmamış Mesajlar', hint: 'Yanıt bekleyen mesajlar', icon: '🔔', color: 'stat-red' }
            ];

            return defaults[index] || {
                title: 'Genel Durum',
                hint: 'Panel özeti',
                icon: '📊',
                color: 'stat-blue'
            };
        }

        function findCards() {
            var selectors = [
                '.dashboard-stats > *',
                '.stats-grid > *',
                '.stat-card',
                '.dashboard-card',
                '.dashboard-stat-polished'
            ];

            var found = [];

            selectors.forEach(function (selector) {
                document.querySelectorAll(selector).forEach(function (item) {
                    if (found.indexOf(item) === -1) {
                        found.push(item);
                    }
                });
            });

            return found.filter(function (card) {
                var text = normalizeText(card.textContent);

                if (!text) return false;
                if (card.closest('.sidebar, .admin-sidebar, aside')) return false;

                return text.match(/\d/) !== null || card.classList.contains('dashboard-stat-polished');
            });
        }

        var cards = findCards();

        cards.forEach(function (card, index) {
            var rawText = card.textContent.trim();
            var number = cleanNumber(rawText);
            var meta = resolveCardMeta(rawText, index);

            card.classList.remove('stat-blue', 'stat-green', 'stat-purple', 'stat-orange', 'stat-red', 'stat-cyan', 'stat-slate', 'stat-pink');
            card.classList.add('dashboard-stat-polished', meta.color);

            card.innerHTML = ''
                + '<div class="dashboard-stat-inner">'
                    + '<div class="dashboard-stat-main">'
                        + '<span class="dashboard-stat-label">' + meta.title + '</span>'
                        + '<span class="dashboard-stat-value">' + number + '</span>'
                        + '<span class="dashboard-stat-hint">↗ ' + meta.hint + '</span>'
                    + '</div>'
                    + '<span class="dashboard-stat-icon">' + meta.icon + '</span>'
                + '</div>';
        });
    });
</script>
<!-- dashboard-card-title-fix-script-end -->
<!-- mobile-sidebar-logout-fix-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && attempt > 3) {
                callback(sidebar);
                return;
            }

            if (sidebar && sidebar.querySelector('.admin-sidebar-bottom')) {
                callback(sidebar);
                return;
            }

            if (attempt > 25) {
                if (sidebar) {
                    callback(sidebar);
                }
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) {
                return;
            }

            sidebar.classList.add('mobile-logout-ready');

            function ensureLogoutVisible() {
                var bottom = sidebar.querySelector('.admin-sidebar-bottom');

                if (!bottom) {
                    return;
                }

                if (window.innerWidth <= 768) {
                    sidebar.style.overflowY = 'auto';
                    sidebar.style.maxHeight = '100dvh';
                    sidebar.style.height = '100dvh';

                    bottom.style.position = 'sticky';
                    bottom.style.bottom = '0';
                    bottom.style.zIndex = '20';
                }
            }

            ensureLogoutVisible();

            window.addEventListener('resize', ensureLogoutVisible);
            window.addEventListener('orientationchange', function () {
                setTimeout(ensureLogoutVisible, 250);
            });
        });
    });
</script>
<!-- mobile-sidebar-logout-fix-script-end -->
<!-- clean-admin-topbar-user-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var topbar = document.querySelector('.topbar, .admin-topbar, header');

        if (!topbar || topbar.dataset.userInfoCleaned === '1') {
            return;
        }

        topbar.dataset.userInfoCleaned = '1';

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function looksLikeEmail(text) {
            return /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i.test(text);
        }

        /*
        |--------------------------------------------------------------------------
        | 1. Mail adresi içeren küçük kullanıcı bloklarını gizle
        |--------------------------------------------------------------------------
        */

        Array.prototype.slice.call(topbar.querySelectorAll('div, span, p, small, strong')).forEach(function (el) {
            var text = normalizeText(el.textContent);

            if (!text) {
                return;
            }

            if (looksLikeEmail(text)) {
                var candidate = el.closest('.user-info, .user-details, .admin-user-info, .admin-user-details, .profile-info, .profile-details');

                if (candidate) {
                    candidate.style.display = 'none';
                    return;
                }

                el.style.display = 'none';
            }
        });

        /*
        |--------------------------------------------------------------------------
        | 2. Header içindeki logout tekrarını gizle
        |--------------------------------------------------------------------------
        */

        Array.prototype.slice.call(topbar.querySelectorAll('a[href], form')).forEach(function (el) {
            var text = normalizeText(el.textContent);
            var href = normalizeText(el.getAttribute ? (el.getAttribute('href') || el.getAttribute('action') || '') : '');

            if (
                text.indexOf('çıkış') !== -1 ||
                text.indexOf('cikis') !== -1 ||
                text.indexOf('logout') !== -1 ||
                href.indexOf('logout') !== -1
            ) {
                el.style.display = 'none';
            }
        });

        /*
        |--------------------------------------------------------------------------
        | 3. Sağ tarafa sade küçük panel ikonu ekle
        |--------------------------------------------------------------------------
        */

        var rightArea = topbar.querySelector('.topbar-right, .admin-topbar-right, .header-right');

        if (!rightArea) {
            rightArea = document.createElement('div');
            rightArea.className = 'admin-topbar-right';
            topbar.appendChild(rightArea);
        }

        if (!rightArea.querySelector('.admin-topbar-cleaned-badge')) {
            var badge = document.createElement('span');
            badge.className = 'admin-topbar-cleaned-badge';
            badge.title = 'Admin Panel';
            badge.textContent = 'AP';
            rightArea.appendChild(badge);
        }
    });
</script>
<!-- clean-admin-topbar-user-script-end -->

<!-- sidebar-contact-security-group-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function findOrCreateSection(sidebar, title) {
            var found = null;

            sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                var titleEl = section.querySelector('.admin-sidebar-section-title span');
                var currentTitle = normalizeText(titleEl ? titleEl.textContent : '');

                if (currentTitle === normalizeText(title)) {
                    found = section;
                }
            });

            if (found) {
                return found;
            }

            var section = document.createElement('div');
            section.className = 'admin-sidebar-section';

            var button = document.createElement('button');
            button.type = 'button';
            button.className = 'admin-sidebar-section-title';
            button.innerHTML = '<span>' + title + '</span>';

            var links = document.createElement('div');
            links.className = 'admin-sidebar-section-links';

            button.addEventListener('click', function () {
                section.classList.toggle('is-collapsed');
            });

            section.appendChild(button);
            section.appendChild(links);

            var bottom = sidebar.querySelector('.admin-sidebar-bottom');
            var compact = sidebar.querySelector('.admin-sidebar-compact-toggle');

            if (title === 'Güvenlik') {
                if (compact) {
                    sidebar.insertBefore(section, compact);
                } else if (bottom) {
                    sidebar.insertBefore(section, bottom);
                } else {
                    sidebar.appendChild(section);
                }
            } else {
                var systemSection = null;

                sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (item) {
                    var itemTitle = item.querySelector('.admin-sidebar-section-title span');
                    if (normalizeText(itemTitle ? itemTitle.textContent : '') === 'sistem') {
                        systemSection = item;
                    }
                });

                if (systemSection) {
                    sidebar.insertBefore(section, systemSection);
                } else if (compact) {
                    sidebar.insertBefore(section, compact);
                } else if (bottom) {
                    sidebar.insertBefore(section, bottom);
                } else {
                    sidebar.appendChild(section);
                }
            }

            return section;
        }

        function removeEmptySections(sidebar) {
            sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                var links = section.querySelectorAll('.admin-sidebar-link');

                if (links.length === 0) {
                    section.remove();
                }
            });
        }

        function setIcon(link, iconText) {
            var icon = link.querySelector('.admin-sidebar-link-icon');

            if (icon) {
                icon.textContent = iconText;
            }
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) {
                return;
            }

            /*
            |--------------------------------------------------------------------------
            | Hedef bölümleri oluştur / bul
            |--------------------------------------------------------------------------
            */

            var contentSection = findOrCreateSection(sidebar, 'İçerik Yönetimi');
            var securitySection = findOrCreateSection(sidebar, 'Güvenlik');

            var contentLinks = contentSection.querySelector('.admin-sidebar-section-links');
            var securityLinks = securitySection.querySelector('.admin-sidebar-section-links');

            /*
            |--------------------------------------------------------------------------
            | Linkleri doğru gruplara taşı
            |--------------------------------------------------------------------------
            */

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                var isContactMessages =
                    text.indexOf('iletişim mesajları') !== -1 ||
                    text.indexOf('iletisim mesajlari') !== -1 ||
                    href.indexOf('/admin/contact-messages') !== -1;

                var isLoginAttempts =
                    text.indexOf('login denemeleri') !== -1 ||
                    href.indexOf('/admin/login-attempts') !== -1;

                if (isContactMessages) {
                    setIcon(link, '✉️');
                    contentLinks.appendChild(link);
                }

                if (isLoginAttempts) {
                    setIcon(link, '🛡️');
                    securityLinks.appendChild(link);
                }
            });

            /*
            |--------------------------------------------------------------------------
            | Güvenlik başlığı sadece Login Denemeleri için kalsın
            |--------------------------------------------------------------------------
            */

            var securityTitle = securitySection.querySelector('.admin-sidebar-section-title span');

            if (securityTitle) {
                securityTitle.textContent = 'Güvenlik';
            }

            var contentTitle = contentSection.querySelector('.admin-sidebar-section-title span');

            if (contentTitle) {
                contentTitle.textContent = 'İçerik Yönetimi';
            }

            /*
            |--------------------------------------------------------------------------
            | Aktif link varsa ilgili bölümü açık tut
            |--------------------------------------------------------------------------
            */

            sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                if (section.querySelector('.admin-sidebar-link.is-active')) {
                    section.classList.remove('is-collapsed');
                }
            });

            removeEmptySections(sidebar);
        });
    });
</script>
<!-- sidebar-contact-security-group-fix-end -->
<!-- theme-settings-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text.indexOf('tema ayarları') !== -1 || text.indexOf('tema ayarlari') !== -1 || href.indexOf('/admin/theme-settings') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '🎨';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- theme-settings-sidebar-fix-end -->
<!-- sidebar-layout-stability-script-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 30)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar || sidebar.dataset.layoutStabilityReady === '1') {
                return;
            }

            sidebar.dataset.layoutStabilityReady = '1';

            /*
            |--------------------------------------------------------------------------
            | 1. Alt alanı bul / oluştur
            |--------------------------------------------------------------------------
            */

            var bottom = sidebar.querySelector('.admin-sidebar-bottom');

            if (!bottom) {
                bottom = document.createElement('div');
                bottom.className = 'admin-sidebar-bottom';
                sidebar.appendChild(bottom);
            }

            /*
            |--------------------------------------------------------------------------
            | 2. Daralt butonunu alt alana taşı
            |--------------------------------------------------------------------------
            */

            var compactButton = sidebar.querySelector('.admin-sidebar-compact-toggle');

            if (compactButton && compactButton.parentNode !== bottom) {
                bottom.insertBefore(compactButton, bottom.firstChild);
            }

            /*
            |--------------------------------------------------------------------------
            | 3. Logout form/link alt alanda kalsın
            |--------------------------------------------------------------------------
            */

            var logoutForm = sidebar.querySelector('.admin-sidebar-logout-form');
            var logoutButton = sidebar.querySelector('.admin-sidebar-logout-fixed');

            if (logoutForm && logoutForm.parentNode !== bottom) {
                bottom.appendChild(logoutForm);
            } else if (logoutButton && logoutButton.parentNode !== bottom) {
                bottom.appendChild(logoutButton);
            }

            /*
            |--------------------------------------------------------------------------
            | 4. Menü alanını ayrı scroll wrapper içine al
            |--------------------------------------------------------------------------
            */

            if (!sidebar.querySelector('.admin-sidebar-scroll-area')) {
                var scrollArea = document.createElement('div');
                scrollArea.className = 'admin-sidebar-scroll-area';

                var children = Array.prototype.slice.call(sidebar.childNodes);

                children.forEach(function (child) {
                    if (child === bottom) {
                        return;
                    }

                    scrollArea.appendChild(child);
                });

                sidebar.insertBefore(scrollArea, bottom);
            }

            /*
            |--------------------------------------------------------------------------
            | 5. Butonların üst üste binmesini engelle
            |--------------------------------------------------------------------------
            */

            var bottomCompact = bottom.querySelector('.admin-sidebar-compact-toggle');
            var bottomLogoutForm = bottom.querySelector('.admin-sidebar-logout-form');
            var bottomLogoutLink = bottom.querySelector('.admin-sidebar-logout-fixed');

            if (bottomCompact) {
                bottomCompact.style.position = 'relative';
                bottomCompact.style.zIndex = '2';
            }

            if (bottomLogoutForm) {
                bottomLogoutForm.style.position = 'relative';
                bottomLogoutForm.style.zIndex = '2';
            }

            if (bottomLogoutLink) {
                bottomLogoutLink.style.position = 'relative';
                bottomLogoutLink.style.zIndex = '2';
            }

            /*
            |--------------------------------------------------------------------------
            | 6. Scroll alanı yüksekliğini güvenli tut
            |--------------------------------------------------------------------------
            */

            function syncSidebarHeight() {
                sidebar.style.height = '100dvh';
                sidebar.style.maxHeight = '100dvh';
                sidebar.style.overflow = 'hidden';
            }

            syncSidebarHeight();

            window.addEventListener('resize', syncSidebarHeight);
            window.addEventListener('orientationchange', function () {
                setTimeout(syncSidebarHeight, 250);
            });
        });
    });
</script>
<!-- sidebar-layout-stability-script-end -->
<!-- admin-logs-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text === 'loglar' || href.indexOf('/admin/logs') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '📜';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- admin-logs-sidebar-fix-end -->
<!-- theme-presets-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text.indexOf('tema presetleri') !== -1 || href.indexOf('/admin/theme-presets') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '🎛️';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- theme-presets-sidebar-fix-end -->
<!-- admin-backups-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text === 'yedekleme' || href.indexOf('/admin/backups') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '💾';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- admin-backups-sidebar-fix-end -->
<!-- admin-seo-checks-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text === 'seo kontrol' || href.indexOf('/admin/seo-checks') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '🔎';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- admin-seo-checks-sidebar-fix-end -->
<!-- content-versions-sidebar-fix-start -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        function waitForSidebar(callback, attempt) {
            attempt = attempt || 0;

            var sidebar = document.querySelector('.sidebar, .admin-sidebar, aside');

            if (sidebar && (sidebar.querySelector('.admin-sidebar-section') || attempt > 25)) {
                callback(sidebar);
                return;
            }

            setTimeout(function () {
                waitForSidebar(callback, attempt + 1);
            }, 100);
        }

        function normalizeText(value) {
            return String(value || '')
                .toLocaleLowerCase('tr-TR')
                .replace(/\s+/g, ' ')
                .trim();
        }

        waitForSidebar(function (sidebar) {
            if (!sidebar) return;

            sidebar.querySelectorAll('.admin-sidebar-link').forEach(function (link) {
                var text = normalizeText(link.textContent);
                var href = normalizeText(link.getAttribute('href') || '');

                if (text === 'sürüm geçmişi' || text === 'surum gecmisi' || href.indexOf('/admin/content-versions') !== -1) {
                    var icon = link.querySelector('.admin-sidebar-link-icon');

                    if (icon) {
                        icon.textContent = '🕘';
                    }

                    var systemSection = null;

                    sidebar.querySelectorAll('.admin-sidebar-section').forEach(function (section) {
                        var title = normalizeText(section.querySelector('.admin-sidebar-section-title span') ? section.querySelector('.admin-sidebar-section-title span').textContent : '');

                        if (title === 'sistem') {
                            systemSection = section;
                        }
                    });

                    if (systemSection) {
                        var links = systemSection.querySelector('.admin-sidebar-section-links');

                        if (links) {
                            links.appendChild(link);
                        }
                    }
                }
            });
        });
    });
</script>
<!-- content-versions-sidebar-fix-end -->
</body>
</html>
